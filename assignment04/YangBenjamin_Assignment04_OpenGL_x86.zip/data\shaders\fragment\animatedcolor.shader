	#version 420
layout( std140, binding = 0 ) uniform g_constantBuffer_frame
{
	mat4 g_transform_worldToCamera;
	mat4 g_transform_cameraToProjected;
	float g_elapsedSecondCount_systemTime;
	float g_elapsedSecondCount_simulationTime;
	vec2 g_padding;
};
out vec4 o_color;
void main()
{
	const float red = 0.5 + 0.5 * sin( g_elapsedSecondCount_simulationTime );
	const float green = 0.5 + 0.5 * sin( g_elapsedSecondCount_simulationTime + 2.094 );
	const float blue = 0.5 + 0.5 * sin( g_elapsedSecondCount_simulationTime + 4.188 );
	o_color = vec4( red, green, blue, 1.0 );
}

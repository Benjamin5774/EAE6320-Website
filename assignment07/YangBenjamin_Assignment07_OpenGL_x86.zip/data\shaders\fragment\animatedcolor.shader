	#version 420
layout( std140, binding = 0 ) uniform g_constantBuffer_frame
{
	mat4 g_transform_worldToCamera;
	mat4 g_transform_cameraToProjected;
	float g_elapsedSecondCount_systemTime;
	float g_elapsedSecondCount_simulationTime;
	vec2 g_padding;
};
layout( std140, binding = 2 ) uniform g_constantBuffer_drawCall
{
	mat4 g_transform_localToWorld;
};
layout( location = 0 ) in vec4 i_fragmentColor;
out vec4 o_color;
void main()
{
	float red = 0.5 + 0.5 * sin( g_elapsedSecondCount_simulationTime );
	float green = 0.5 + 0.5 * sin( g_elapsedSecondCount_simulationTime + 2.094 );
	float blue = 0.5 + 0.5 * sin( g_elapsedSecondCount_simulationTime + 4.188 );
	vec4 animatedColor = vec4( red, green, blue, 1.0 );
	o_color = animatedColor * i_fragmentColor;
}

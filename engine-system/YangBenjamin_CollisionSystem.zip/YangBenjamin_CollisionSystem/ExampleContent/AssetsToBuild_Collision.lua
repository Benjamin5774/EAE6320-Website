--[[
	The two tables to add to your MyGame_/Content/AssetsToBuild.lua
	(next to "shaders" and "meshes", inside the table that the file returns)

	List the files that are really in your content directory.
	The built files end up at data/Collision/game.binlayers and data/Colliders/<name>.bincollider
	(the paths that your game passes to Collision::Initialize() and cCollider::Load()).
]]

	collisionlayers =
	{
		"Collision/game.layers",
	},
	colliders =
	{
		"Colliders/player.collider",
		"Colliders/enemy.collider",
		"Colliders/floor.collider",
		"Colliders/wall.collider",
		"Colliders/crate.collider",
		"Colliders/pickup.collider",
	},

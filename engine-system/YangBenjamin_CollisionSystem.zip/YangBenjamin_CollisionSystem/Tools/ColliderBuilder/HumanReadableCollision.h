/*
	Reads the two kinds of human-readable collision file (both are Lua tables):
		* a layers file (e.g. MyGame_/Content/Collision/game.layers):
			the game's layers and which pairs of them touch each other
		* a collider file (e.g. MyGame_/Content/Colliders/player.collider):
			one collider's shape, size, center, layer and flags

	This is the only part of ColliderBuilder that knows about Lua.
	Every problem is reported with OutputErrorMessageWithFileInfo() so that it shows up in Visual Studio's Error List.
	Lua knows the line number of a syntax error;
	for a value that is wrong the line is found by looking for the key or the name in the file,
	so that double clicking the error almost always goes to the right line.
*/

#ifndef EAE6320_HUMANREADABLECOLLISION_H
#define EAE6320_HUMANREADABLECOLLISION_H

// Includes
//=========

#include <cstdint>
#include <Engine/Collision/ColliderFormats.h>
#include <Engine/Results/Results.h>
#include <string>
#include <vector>

// Interface
//==========

namespace eae6320
{
	namespace Assets
	{
		struct sCollisionLayers
		{
			// In the order of the file (a layer's index is its position in this list)
			std::vector<std::string> names;
			// One per layer: bit b of interactionMasks[a] is set if layers a and b touch each other
			std::vector<uint32_t> interactionMasks;
		};

		cResult LoadHumanReadableCollisionLayers( const char* const i_path, sCollisionLayers& o_layers );
		// The collider's layer name is looked up in i_layers
		cResult LoadHumanReadableCollider( const char* const i_path, const sCollisionLayers& i_layers,
			Collision::ColliderFormats::sCollider& o_collider );
	}
}

#endif	// EAE6320_HUMANREADABLECOLLISION_H

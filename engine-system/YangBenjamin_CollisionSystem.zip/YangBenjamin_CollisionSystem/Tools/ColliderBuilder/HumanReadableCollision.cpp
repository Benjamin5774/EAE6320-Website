// Includes
//=========

#include "HumanReadableCollision.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <Engine/Asserts/Asserts.h>
#include <Engine/ScopeGuard/cScopeGuard.h>
#include <External/Lua/Includes.h>
#include <fstream>
#include <regex>
#include <Tools/AssetBuildLibrary/Functions.h>

// Helper Declarations
//====================

namespace
{
	// Error Output
	//-------------

	// Reports a problem with a file so that it shows up in Visual Studio's Error List
	// (i_lineNumber is 0 if the line isn't known)
	void OutputError( const char* const i_path, const unsigned int i_lineNumber, const char* const i_message, ... );
	// Reports a problem that Lua found, with the line number from Lua's message
	void OutputLuaError( const char* const i_path, const char* const i_whatFailed, const char* const i_luaMessage );

	// Line Numbers
	//-------------

	// A Lua table doesn't remember where its values were written,
	// so for a problem with a value the file is searched for the line where it is most likely to be.
	// Comments are ignored, and 0 means that nothing was found.

	// The first line where "i_key =" is written
	unsigned int FindLineOfKey( const char* const i_path, const std::string& i_key );
	// The line where i_text is written in quotes for the i_occurrence-th time
	unsigned int FindLineOfString( const char* const i_path, const std::string& i_text, const unsigned int i_occurrence = 1 );

	// Lua
	//----

	// Loads and runs a human-readable file, leaving the table that it returns at the top of the stack
	// (if it fails the problem has been reported and nothing is left on the stack)
	eae6320::cResult LoadAssetTable( lua_State& io_luaState, const char* const i_path, const char* const i_fileDescription );
	// Checks that every key of the table at the top of the stack is one of i_validKeys
	// (so that a misspelled key, e.g. "isTriger", is reported instead of being silently ignored)
	eae6320::cResult CheckKeys( lua_State& io_luaState, const char* const i_path, const char* const i_tableDescription,
		const std::vector<std::string>& i_validKeys );
	// Reads the table at the top of the stack as { x = ..., y = ..., z = ... }
	// (if i_areComponentsRequired is false a missing component is 0)
	eae6320::cResult ReadVector( lua_State& io_luaState, const char* const i_path, const char* const i_key,
		const bool i_areComponentsRequired, eae6320::Math::sVector& o_vector );

	// Joins names with commas (for error messages that list what would have been valid)
	std::string JoinNames( const std::vector<std::string>& i_names );
}

// Interface
//==========

eae6320::cResult eae6320::Assets::LoadHumanReadableCollisionLayers( const char* const i_path, sCollisionLayers& o_layers )
{
	auto result = Results::Success;

	o_layers.names.clear();
	o_layers.interactionMasks.clear();

	// Create a new Lua state
	lua_State* luaState = nullptr;
	cScopeGuard scopeGuard_onExit( [&luaState]
		{
			if ( luaState )
			{
				// If this assert fails then something is being left on the stack
				EAE6320_ASSERT( lua_gettop( luaState ) == 0 );
				lua_close( luaState );
				luaState = nullptr;
			}
		} );
	{
		luaState = luaL_newstate();
		if ( !luaState )
		{
			result = Results::OutOfMemory;
			OutputErrorMessageWithFileInfo( i_path, "Failed to create a new Lua state" );
			return result;
		}
	}

	// Load the file's table
	if ( !( result = LoadAssetTable( *luaState, i_path, "layers file" ) ) )
	{
		return result;
	}
	cScopeGuard scopeGuard_popAssetTable( [luaState]
		{
			lua_pop( luaState, 1 );
		} );
	if ( !( result = CheckKeys( *luaState, i_path, "The layers file", { "layers", "interactions" } ) ) )
	{
		return result;
	}

	// Layers
	// (an array of names; a layer's index is its position in the array)
	{
		constexpr auto* const key = "layers";
		lua_getfield( luaState, -1, key );
		cScopeGuard scopeGuard_popLayers( [luaState]
			{
				lua_pop( luaState, 1 );
			} );
		if ( !lua_istable( luaState, -1 ) )
		{
			result = Results::InvalidFile;
			OutputError( i_path, FindLineOfKey( i_path, key ),
				"The layers file must have a \"%s\" table with the names of the game's layers, e.g. { \"world\", \"player\" } (instead of a %s)",
				key, luaL_typename( luaState, -1 ) );
			return result;
		}
		const auto layerCount = luaL_len( luaState, -1 );
		if ( ( layerCount < 1 ) || ( layerCount > static_cast<lua_Integer>( Collision::MaxLayerCount ) ) )
		{
			result = Results::InvalidFile;
			OutputError( i_path, FindLineOfKey( i_path, key ), "There must be between 1 and %u layers (there are %lld)",
				Collision::MaxLayerCount, static_cast<long long>( layerCount ) );
			return result;
		}
		for ( lua_Integer i = 1; i <= layerCount; ++i )
		{
			lua_rawgeti( luaState, -1, i );
			cScopeGuard scopeGuard_popLayer( [luaState]
				{
					lua_pop( luaState, 1 );
				} );
			// (lua_isstring() would also accept a number, which is almost certainly a mistake)
			if ( lua_type( luaState, -1 ) != LUA_TSTRING )
			{
				result = Results::InvalidFile;
				OutputError( i_path, FindLineOfKey( i_path, key ), "Layer %lld must be a name in quotes (instead of a %s)",
					static_cast<long long>( i ), luaL_typename( luaState, -1 ) );
				return result;
			}
			const std::string name = lua_tostring( luaState, -1 );
			if ( name.empty() )
			{
				result = Results::InvalidFile;
				OutputError( i_path, FindLineOfKey( i_path, key ), "Layer %lld has an empty name", static_cast<long long>( i ) );
				return result;
			}
			if ( std::find( o_layers.names.begin(), o_layers.names.end(), name ) != o_layers.names.end() )
			{
				result = Results::InvalidFile;
				OutputError( i_path, FindLineOfString( i_path, name, 2 ), "The layer \"%s\" is listed more than once", name.c_str() );
				return result;
			}
			o_layers.names.push_back( name );
		}
	}
	o_layers.interactionMasks.assign( o_layers.names.size(), 0 );

	// Interactions
	// (an array of pairs of layer names; layers that aren't paired anywhere never touch each other)
	{
		constexpr auto* const key = "interactions";
		lua_getfield( luaState, -1, key );
		cScopeGuard scopeGuard_popInteractions( [luaState]
			{
				lua_pop( luaState, 1 );
			} );
		if ( !lua_istable( luaState, -1 ) )
		{
			result = Results::InvalidFile;
			OutputError( i_path, FindLineOfKey( i_path, key ),
				"The layers file must have an \"%s\" table that lists which layers touch each other, e.g. { { \"player\", \"world\" } }"
				" (instead of a %s)", key, luaL_typename( luaState, -1 ) );
			return result;
		}
		const auto interactionCount = luaL_len( luaState, -1 );
		for ( lua_Integer i = 1; i <= interactionCount; ++i )
		{
			lua_rawgeti( luaState, -1, i );
			cScopeGuard scopeGuard_popInteraction( [luaState]
				{
					lua_pop( luaState, 1 );
				} );
			if ( !lua_istable( luaState, -1 ) || ( luaL_len( luaState, -1 ) != 2 ) )
			{
				result = Results::InvalidFile;
				OutputError( i_path, FindLineOfKey( i_path, key ),
					"Interaction %lld must be a pair of layer names, e.g. { \"player\", \"world\" }", static_cast<long long>( i ) );
				return result;
			}
			size_t layerIndices[2] = {};
			for ( int j = 0; j < 2; ++j )
			{
				lua_rawgeti( luaState, -1, j + 1 );
				cScopeGuard scopeGuard_popName( [luaState]
					{
						lua_pop( luaState, 1 );
					} );
				if ( lua_type( luaState, -1 ) != LUA_TSTRING )
				{
					result = Results::InvalidFile;
					OutputError( i_path, FindLineOfKey( i_path, key ), "Interaction %lld must be a pair of layer names in quotes (instead of a %s)",
						static_cast<long long>( i ), luaL_typename( luaState, -1 ) );
					return result;
				}
				const std::string name = lua_tostring( luaState, -1 );
				const auto layer = std::find( o_layers.names.begin(), o_layers.names.end(), name );
				if ( layer == o_layers.names.end() )
				{
					result = Results::InvalidFile;
					OutputError( i_path, FindLineOfString( i_path, name ),
						"Interaction %lld refers to the layer \"%s\", which isn't in the \"layers\" table (the layers are: %s)",
						static_cast<long long>( i ), name.c_str(), JoinNames( o_layers.names ).c_str() );
					return result;
				}
				layerIndices[j] = static_cast<size_t>( layer - o_layers.names.begin() );
			}
			// Touching goes both ways
			// (a layer can also be paired with itself, e.g. { "enemy", "enemy" } if enemies bump into each other)
			o_layers.interactionMasks[layerIndices[0]] |= uint32_t( 1 ) << layerIndices[1];
			o_layers.interactionMasks[layerIndices[1]] |= uint32_t( 1 ) << layerIndices[0];
		}
	}

	return result;
}

eae6320::cResult eae6320::Assets::LoadHumanReadableCollider( const char* const i_path, const sCollisionLayers& i_layers,
	Collision::ColliderFormats::sCollider& o_collider )
{
	auto result = Results::Success;

	o_collider = Collision::ColliderFormats::sCollider();

	// Create a new Lua state
	lua_State* luaState = nullptr;
	cScopeGuard scopeGuard_onExit( [&luaState]
		{
			if ( luaState )
			{
				// If this assert fails then something is being left on the stack
				EAE6320_ASSERT( lua_gettop( luaState ) == 0 );
				lua_close( luaState );
				luaState = nullptr;
			}
		} );
	{
		luaState = luaL_newstate();
		if ( !luaState )
		{
			result = Results::OutOfMemory;
			OutputErrorMessageWithFileInfo( i_path, "Failed to create a new Lua state" );
			return result;
		}
	}

	// Load the file's table
	if ( !( result = LoadAssetTable( *luaState, i_path, "collider file" ) ) )
	{
		return result;
	}
	cScopeGuard scopeGuard_popAssetTable( [luaState]
		{
			lua_pop( luaState, 1 );
		} );
	if ( !( result = CheckKeys( *luaState, i_path, "The collider file",
		{ "shape", "radius", "halfSize", "center", "layer", "isTrigger", "isStatic" } ) ) )
	{
		return result;
	}

	// Shape
	{
		constexpr auto* const key = "shape";
		lua_getfield( luaState, -1, key );
		cScopeGuard scopeGuard_popShape( [luaState]
			{
				lua_pop( luaState, 1 );
			} );
		if ( lua_type( luaState, -1 ) != LUA_TSTRING )
		{
			result = Results::InvalidFile;
			OutputError( i_path, FindLineOfKey( i_path, key ), "The collider file must have a \"%s\": \"sphere\" or \"box\" (instead of a %s)",
				key, luaL_typename( luaState, -1 ) );
			return result;
		}
		const std::string shape = lua_tostring( luaState, -1 );
		if ( shape == "sphere" )
		{
			o_collider.shape = Collision::eShape::Sphere;
		}
		else if ( shape == "box" )
		{
			o_collider.shape = Collision::eShape::Box;
		}
		else
		{
			result = Results::InvalidFile;
			OutputError( i_path, FindLineOfKey( i_path, key ), "The shape \"%s\" isn't one that the collision system knows (use \"sphere\" or \"box\")",
				shape.c_str() );
			return result;
		}
	}

	// Size
	// (each shape has its own size value, and a value that belongs to the other shape is an error:
	// it almost always means that the shape was changed and the size wasn't)
	if ( o_collider.shape == Collision::eShape::Sphere )
	{
		{
			constexpr auto* const key = "radius";
			lua_getfield( luaState, -1, key );
			cScopeGuard scopeGuard_popRadius( [luaState]
				{
					lua_pop( luaState, 1 );
				} );
			if ( lua_type( luaState, -1 ) != LUA_TNUMBER )
			{
				result = Results::InvalidFile;
				const auto lineNumber = lua_isnil( luaState, -1 ) ? FindLineOfKey( i_path, "shape" ) : FindLineOfKey( i_path, key );
				OutputError( i_path, lineNumber, "A sphere must have a \"%s\" (a number, instead of a %s)", key, luaL_typename( luaState, -1 ) );
				return result;
			}
			const auto radius = static_cast<float>( lua_tonumber( luaState, -1 ) );
			// (written so that NaN fails too)
			if ( !( radius > 0.0f ) || !std::isfinite( radius ) )
			{
				result = Results::InvalidFile;
				OutputError( i_path, FindLineOfKey( i_path, key ), "The \"%s\" must be a number greater than 0 (it is %g)", key, radius );
				return result;
			}
			o_collider.radius = radius;
			// The bounding box of a sphere
			o_collider.halfSize = Math::sVector( radius, radius, radius );
		}
		{
			constexpr auto* const key = "halfSize";
			lua_getfield( luaState, -1, key );
			cScopeGuard scopeGuard_popHalfSize( [luaState]
				{
					lua_pop( luaState, 1 );
				} );
			if ( !lua_isnil( luaState, -1 ) )
			{
				result = Results::InvalidFile;
				OutputError( i_path, FindLineOfKey( i_path, key ),
					"A sphere doesn't have a \"%s\" (only a box does): remove it, or change the shape to \"box\"", key );
				return result;
			}
		}
	}
	else
	{
		{
			constexpr auto* const key = "halfSize";
			lua_getfield( luaState, -1, key );
			cScopeGuard scopeGuard_popHalfSize( [luaState]
				{
					lua_pop( luaState, 1 );
				} );
			if ( !lua_istable( luaState, -1 ) )
			{
				result = Results::InvalidFile;
				const auto lineNumber = lua_isnil( luaState, -1 ) ? FindLineOfKey( i_path, "shape" ) : FindLineOfKey( i_path, key );
				OutputError( i_path, lineNumber,
					"A box must have a \"%s\" table (half of its size along each axis, e.g. { x = 1.0, y = 0.5, z = 1.0 }) instead of a %s",
					key, luaL_typename( luaState, -1 ) );
				return result;
			}
			constexpr bool areComponentsRequired = true;
			if ( !( result = ReadVector( *luaState, i_path, key, areComponentsRequired, o_collider.halfSize ) ) )
			{
				return result;
			}
			if ( !( o_collider.halfSize.x > 0.0f ) || !( o_collider.halfSize.y > 0.0f ) || !( o_collider.halfSize.z > 0.0f ) )
			{
				result = Results::InvalidFile;
				OutputError( i_path, FindLineOfKey( i_path, key ),
					"Every component of the \"%s\" must be greater than 0 (it is { x = %g, y = %g, z = %g })",
					key, o_collider.halfSize.x, o_collider.halfSize.y, o_collider.halfSize.z );
				return result;
			}
			o_collider.radius = 0.0f;
		}
		{
			constexpr auto* const key = "radius";
			lua_getfield( luaState, -1, key );
			cScopeGuard scopeGuard_popRadius( [luaState]
				{
					lua_pop( luaState, 1 );
				} );
			if ( !lua_isnil( luaState, -1 ) )
			{
				result = Results::InvalidFile;
				OutputError( i_path, FindLineOfKey( i_path, key ),
					"A box doesn't have a \"%s\" (only a sphere does): remove it, or change the shape to \"sphere\"", key );
				return result;
			}
		}
	}

	// Center (optional)
	// (an offset from the position of the object that the collider is attached to)
	{
		constexpr auto* const key = "center";
		lua_getfield( luaState, -1, key );
		cScopeGuard scopeGuard_popCenter( [luaState]
			{
				lua_pop( luaState, 1 );
			} );
		if ( lua_istable( luaState, -1 ) )
		{
			// Any component that isn't written is 0, so e.g. { y = 0.5 } is enough to raise a collider
			constexpr bool areComponentsRequired = false;
			if ( !( result = ReadVector( *luaState, i_path, key, areComponentsRequired, o_collider.center ) ) )
			{
				return result;
			}
		}
		else if ( !lua_isnil( luaState, -1 ) )
		{
			result = Results::InvalidFile;
			OutputError( i_path, FindLineOfKey( i_path, key ), "The \"%s\" must be a table like { x = 0.0, y = 0.5, z = 0.0 } (instead of a %s)",
				key, luaL_typename( luaState, -1 ) );
			return result;
		}
		// (no center means that the shape is centered on the object)
	}

	// Layer
	// (the name is turned into the layer's index here, so the run-time never has to compare strings)
	{
		constexpr auto* const key = "layer";
		lua_getfield( luaState, -1, key );
		cScopeGuard scopeGuard_popLayer( [luaState]
			{
				lua_pop( luaState, 1 );
			} );
		if ( lua_type( luaState, -1 ) != LUA_TSTRING )
		{
			result = Results::InvalidFile;
			OutputError( i_path, FindLineOfKey( i_path, key ), "The collider file must have a \"%s\": the name of one of the game's layers (%s)"
				" instead of a %s", key, JoinNames( i_layers.names ).c_str(), luaL_typename( luaState, -1 ) );
			return result;
		}
		const std::string layerName = lua_tostring( luaState, -1 );
		const auto layer = std::find( i_layers.names.begin(), i_layers.names.end(), layerName );
		if ( layer == i_layers.names.end() )
		{
			result = Results::InvalidFile;
			OutputError( i_path, FindLineOfString( i_path, layerName ),
				"The layer \"%s\" isn't in the game's layers file (Collision/game.layers); the layers are: %s",
				layerName.c_str(), JoinNames( i_layers.names ).c_str() );
			return result;
		}
		o_collider.layer = static_cast<uint8_t>( layer - i_layers.names.begin() );
	}

	// Flags (optional, false if they aren't written)
	{
		struct sFlag
		{
			const char* key;
			uint8_t bit;
		};
		constexpr sFlag flags[] =
		{
			{ "isTrigger", Collision::ColliderFormats::Flags::IsTrigger },
			{ "isStatic", Collision::ColliderFormats::Flags::IsStatic },
		};
		for ( const auto& flag : flags )
		{
			lua_getfield( luaState, -1, flag.key );
			cScopeGuard scopeGuard_popFlag( [luaState]
				{
					lua_pop( luaState, 1 );
				} );
			if ( lua_isboolean( luaState, -1 ) )
			{
				if ( lua_toboolean( luaState, -1 ) )
				{
					o_collider.flags |= flag.bit;
				}
			}
			else if ( !lua_isnil( luaState, -1 ) )
			{
				result = Results::InvalidFile;
				OutputError( i_path, FindLineOfKey( i_path, flag.key ), "\"%s\" must be true or false (instead of a %s)",
					flag.key, luaL_typename( luaState, -1 ) );
				return result;
			}
		}
	}

	return result;
}

// Helper Definitions
//===================

namespace
{
	// Error Output
	//-------------

	void OutputError( const char* const i_path, const unsigned int i_lineNumber, const char* const i_message, ... )
	{
		char message[1024];
		{
			va_list insertions;
			va_start( insertions, i_message );
			std::vsnprintf( message, sizeof( message ), i_message, insertions );
			va_end( insertions );
		}
		if ( i_lineNumber > 0 )
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, i_lineNumber, "%s", message );
		}
		else
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, "%s", message );
		}
	}

	void OutputLuaError( const char* const i_path, const char* const i_whatFailed, const char* const i_luaMessage )
	{
		// Lua puts the line number in its message ("<file>:<line>: <message>", or "<file>(<line>) : error: <message>" with the engine's Lua),
		// and it is passed on separately so that double clicking the error in Visual Studio goes to that line
		// (only the line part is looked for, because Lua may shorten a long path with "...")
		const std::regex lineAndMessage( R"((?::(\d+): |\((\d+)\) : error: )(.*)$)" );
		std::cmatch match;
		if ( i_luaMessage && std::regex_search( i_luaMessage, match, lineAndMessage ) )
		{
			const auto lineNumber = static_cast<unsigned int>( std::stoul( match[1].matched ? match[1].str() : match[2].str() ) );
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, lineNumber, "%s: %s", i_whatFailed, match[3].str().c_str() );
		}
		else
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, "%s: %s", i_whatFailed, i_luaMessage ? i_luaMessage : "(no message)" );
		}
	}

	// Line Numbers
	//-------------

	// Returns the number of the first line (counting from 1) for which i_doesLineMatch() returns true,
	// passing it each line with the comments taken out (0 if no line matches)
	template<typename tFunction>
	unsigned int FindLine( const char* const i_path, const tFunction& i_doesLineMatch )
	{
		std::ifstream file( i_path );
		if ( !file.is_open() )
		{
			return 0;
		}
		std::string line;
		unsigned int lineNumber = 0;
		bool isInBlockComment = false;
		while ( std::getline( file, line ) )
		{
			++lineNumber;
			// Keep only the code
			// ("--" starts a comment that goes to the end of the line, "--[[" one that goes to the next "]]")
			std::string code;
			{
				size_t position = 0;
				while ( position < line.size() )
				{
					if ( isInBlockComment )
					{
						const auto commentEnd = line.find( "]]", position );
						if ( commentEnd == std::string::npos )
						{
							position = line.size();
						}
						else
						{
							isInBlockComment = false;
							position = commentEnd + 2;
						}
					}
					else
					{
						const auto commentStart = line.find( "--", position );
						if ( commentStart == std::string::npos )
						{
							code += line.substr( position );
							position = line.size();
						}
						else
						{
							code += line.substr( position, commentStart - position );
							if ( line.compare( commentStart, 4, "--[[" ) == 0 )
							{
								isInBlockComment = true;
								position = commentStart + 4;
							}
							else
							{
								position = line.size();
							}
						}
					}
				}
			}
			if ( i_doesLineMatch( code ) )
			{
				return lineNumber;
			}
		}
		return 0;
	}

	unsigned int FindLineOfKey( const char* const i_path, const std::string& i_key )
	{
		// The key as a whole word followed by "=" (but not "==")
		std::string escapedKey;
		for ( const auto character : i_key )
		{
			if ( !std::isalnum( static_cast<unsigned char>( character ) ) && ( character != '_' ) )
			{
				escapedKey += '\\';
			}
			escapedKey += character;
		}
		const std::regex keyAssignment( "(^|[^A-Za-z0-9_])" + escapedKey + "\\s*=(?!=)" );
		return FindLine( i_path, [&keyAssignment]( const std::string& i_code )
			{
				return std::regex_search( i_code, keyAssignment );
			} );
	}

	unsigned int FindLineOfString( const char* const i_path, const std::string& i_text, const unsigned int i_occurrence )
	{
		const std::string inDoubleQuotes = "\"" + i_text + "\"";
		const std::string inSingleQuotes = "'" + i_text + "'";
		unsigned int occurrenceCount = 0;
		return FindLine( i_path, [&]( const std::string& i_code )
			{
				for ( const auto* const quoted : { &inDoubleQuotes, &inSingleQuotes } )
				{
					for ( auto position = i_code.find( *quoted ); position != std::string::npos; position = i_code.find( *quoted, position + 1 ) )
					{
						if ( ++occurrenceCount == i_occurrence )
						{
							return true;
						}
					}
				}
				return false;
			} );
	}

	// Lua
	//----

	eae6320::cResult LoadAssetTable( lua_State& io_luaState, const char* const i_path, const char* const i_fileDescription )
	{
		auto result = eae6320::Results::Success;

		// Load the file as a "chunk",
		// meaning there will be a callable function at the top of the stack
		const auto stackTopBeforeLoad = lua_gettop( &io_luaState );
		{
			const auto luaResult = luaL_loadfile( &io_luaState, i_path );
			if ( luaResult != LUA_OK )
			{
				// This is where a typo in the file (e.g. a missing comma) is found
				result = eae6320::Results::InvalidFile;
				const std::string whatFailed = std::string( "The " ) + i_fileDescription + " couldn't be loaded";
				OutputLuaError( i_path, whatFailed.c_str(), lua_tostring( &io_luaState, -1 ) );
				// Pop the error message
				lua_pop( &io_luaState, 1 );
				return result;
			}
		}
		// Execute the "chunk", which should leave the file's table at the top of the stack
		{
			constexpr int argumentCount = 0;
			constexpr int returnValueCount = LUA_MULTRET;	// Return _everything_ that the file returns
			constexpr int noMessageHandler = 0;
			const auto luaResult = lua_pcall( &io_luaState, argumentCount, returnValueCount, noMessageHandler );
			if ( luaResult == LUA_OK )
			{
				// A well-behaved file only returns a single table
				const auto returnedValueCount = lua_gettop( &io_luaState ) - stackTopBeforeLoad;
				if ( returnedValueCount == 1 )
				{
					if ( !lua_istable( &io_luaState, -1 ) )
					{
						result = eae6320::Results::InvalidFile;
						eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, "The %s must return a table (instead of a %s)",
							i_fileDescription, luaL_typename( &io_luaState, -1 ) );
						// Pop the returned non-table value
						lua_pop( &io_luaState, 1 );
						return result;
					}
				}
				else
				{
					result = eae6320::Results::InvalidFile;
					eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, "The %s must return a single table (instead of %d values)",
						i_fileDescription, returnedValueCount );
					// Pop every value that was returned
					lua_pop( &io_luaState, returnedValueCount );
					return result;
				}
			}
			else
			{
				result = eae6320::Results::InvalidFile;
				const std::string whatFailed = std::string( "The " ) + i_fileDescription + " couldn't be executed";
				OutputLuaError( i_path, whatFailed.c_str(), lua_tostring( &io_luaState, -1 ) );
				// Pop the error message
				lua_pop( &io_luaState, 1 );
				return result;
			}
		}

		return result;
	}

	eae6320::cResult CheckKeys( lua_State& io_luaState, const char* const i_path, const char* const i_tableDescription,
		const std::vector<std::string>& i_validKeys )
	{
		// lua_next() visits every key of the table (which is at -2 once the starting nil has been pushed),
		// pushing the key and its value each time
		lua_pushnil( &io_luaState );
		while ( lua_next( &io_luaState, -2 ) != 0 )
		{
			// Pop the value; the key has to stay on the stack for the next call to lua_next()
			lua_pop( &io_luaState, 1 );
			if ( lua_type( &io_luaState, -1 ) == LUA_TSTRING )
			{
				const std::string key = lua_tostring( &io_luaState, -1 );
				if ( std::find( i_validKeys.begin(), i_validKeys.end(), key ) == i_validKeys.end() )
				{
					// Pop the key (the loop is stopped early)
					lua_pop( &io_luaState, 1 );
					OutputError( i_path, FindLineOfKey( i_path, key ), "%s has an unknown key \"%s\" (the valid keys are: %s)",
						i_tableDescription, key.c_str(), JoinNames( i_validKeys ).c_str() );
					return eae6320::Results::InvalidFile;
				}
			}
			else
			{
				// e.g. return { "sphere", radius = 0.5 }
				lua_pop( &io_luaState, 1 );
				OutputError( i_path, 0, "%s has a value without a name (every value must be written as name = value; the valid names are: %s)",
					i_tableDescription, JoinNames( i_validKeys ).c_str() );
				return eae6320::Results::InvalidFile;
			}
		}
		return eae6320::Results::Success;
	}

	eae6320::cResult ReadVector( lua_State& io_luaState, const char* const i_path, const char* const i_key,
		const bool i_areComponentsRequired, eae6320::Math::sVector& o_vector )
	{
		auto result = eae6320::Results::Success;

		{
			const std::string tableDescription = std::string( "The \"" ) + i_key + "\" table";
			if ( !( result = CheckKeys( io_luaState, i_path, tableDescription.c_str(), { "x", "y", "z" } ) ) )
			{
				return result;
			}
		}
		constexpr const char* const componentKeys[] = { "x", "y", "z" };
		float* const components[] = { &o_vector.x, &o_vector.y, &o_vector.z };
		for ( size_t i = 0; i < 3; ++i )
		{
			lua_getfield( &io_luaState, -1, componentKeys[i] );
			eae6320::cScopeGuard scopeGuard_popComponent( [&io_luaState]
				{
					lua_pop( &io_luaState, 1 );
				} );
			if ( lua_type( &io_luaState, -1 ) == LUA_TNUMBER )
			{
				const auto value = static_cast<float>( lua_tonumber( &io_luaState, -1 ) );
				if ( !std::isfinite( value ) )
				{
					result = eae6320::Results::InvalidFile;
					OutputError( i_path, FindLineOfKey( i_path, i_key ), "The \"%s\" of the \"%s\" must be a finite number", componentKeys[i], i_key );
					return result;
				}
				*components[i] = value;
			}
			else if ( lua_isnil( &io_luaState, -1 ) && !i_areComponentsRequired )
			{
				*components[i] = 0.0f;
			}
			else
			{
				result = eae6320::Results::InvalidFile;
				OutputError( i_path, FindLineOfKey( i_path, i_key ), "The \"%s\" must have a number \"%s\" (instead of a %s)",
					i_key, componentKeys[i], luaL_typename( &io_luaState, -1 ) );
				return result;
			}
		}

		return result;
	}

	std::string JoinNames( const std::vector<std::string>& i_names )
	{
		std::string joinedNames;
		for ( const auto& name : i_names )
		{
			joinedNames += joinedNames.empty() ? "" : ", ";
			joinedNames += "\"" + name + "\"";
		}
		return joinedNames;
	}
}

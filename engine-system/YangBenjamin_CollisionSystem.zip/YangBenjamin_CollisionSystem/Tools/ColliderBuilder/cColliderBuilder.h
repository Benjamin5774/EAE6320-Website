/*
	This class builds the collision system's files

	It builds both kinds of human-readable collision file (Lua tables) into binary files that the Collision library loads
	(the binary layouts are described in Engine/Collision/ColliderFormats.h):
		* *.layers -> *.binlayers: the game's layers and which of them touch each other
		* *.collider -> *.bincollider: one collider
	The kind of file is decided by the source file's extension.

	A collider file names its layer, and the name is turned into the layer's index at build time,
	so building a collider also reads the game's layers file
	(always Collision/game.layers in the game's content directory).
*/

#ifndef EAE6320_CCOLLIDERBUILDER_H
#define EAE6320_CCOLLIDERBUILDER_H

// Includes
//=========

#include <Tools/AssetBuildLibrary/iBuilder.h>

// Class Declaration
//==================

namespace eae6320
{
	namespace Assets
	{
		class cColliderBuilder final : public iBuilder
		{
			// Inherited Implementation
			//=========================

		private:

			// Build
			//------

			cResult Build( const std::vector<std::string>& i_arguments ) final;

			// Implementation
			//===============

		private:

			cResult BuildLayers();
			cResult BuildCollider();
		};
	}
}

#endif	// EAE6320_CCOLLIDERBUILDER_H

// Includes
//=========

#include "cColliderBuilder.h"

#include "HumanReadableCollision.h"

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <Engine/Collision/ColliderFormats.h>
#include <Engine/Platform/Platform.h>
#include <fstream>
#include <string>
#include <Tools/AssetBuildLibrary/Functions.h>
#include <vector>

// Helper Declarations
//====================

namespace
{
	// Every collider uses the game's layers file, which is always at this path in the game's content directory
	// (AssetBuildFunctions.lua makes every collider depend on the same path)
	constexpr auto* const s_layersRelativePath = "Collision/game.layers";

	eae6320::cResult FindLayersFile( const char* const i_path_collider, std::string& o_path_layers );

	eae6320::cResult WriteBinaryLayers( const char* const i_path, const eae6320::Assets::sCollisionLayers& i_layers );
	eae6320::cResult WriteBinaryCollider( const char* const i_path, const eae6320::Collision::ColliderFormats::sCollider& i_collider );
}

// Inherited Implementation
//=========================

// Build
//------

eae6320::cResult eae6320::Assets::cColliderBuilder::Build( const std::vector<std::string>& )
{
	// (Neither kind of file needs any extra command line arguments; if some are given they are just ignored)

	// The kind of file is decided by its extension
	std::string extension;
	{
		const std::string path_source( m_path_source );
		const auto periodPosition = path_source.find_last_of( '.' );
		if ( ( periodPosition != std::string::npos ) && ( path_source.find_first_of( "/\\", periodPosition ) == std::string::npos ) )
		{
			extension = path_source.substr( periodPosition );
			std::transform( extension.begin(), extension.end(), extension.begin(),
				[]( const char i_character ) { return static_cast<char>( std::tolower( static_cast<unsigned char>( i_character ) ) ); } );
		}
	}
	if ( extension == ".layers" )
	{
		return BuildLayers();
	}
	else if ( extension == ".collider" )
	{
		return BuildCollider();
	}
	else
	{
		OutputErrorMessageWithFileInfo( m_path_source, "ColliderBuilder builds *.layers and *.collider files (not \"%s\" files)",
			extension.empty() ? "extensionless" : extension.c_str() );
		return Results::InvalidFile;
	}
}

// Implementation
//===============

eae6320::cResult eae6320::Assets::cColliderBuilder::BuildLayers()
{
	auto result = Results::Success;

	// Read the human-readable file
	sCollisionLayers layers;
	if ( !( result = LoadHumanReadableCollisionLayers( m_path_source, layers ) ) )
	{
		// (the problem has already been reported with the file's path)
		return result;
	}
	// Write the binary file that the game loads
	if ( !( result = WriteBinaryLayers( m_path_target, layers ) ) )
	{
		return result;
	}

	return result;
}

eae6320::cResult eae6320::Assets::cColliderBuilder::BuildCollider()
{
	auto result = Results::Success;

	// The collider refers to its layer by name, and the names are in the game's layers file
	sCollisionLayers layers;
	{
		std::string path_layers;
		if ( !( result = FindLayersFile( m_path_source, path_layers ) ) )
		{
			return result;
		}
		if ( !( result = LoadHumanReadableCollisionLayers( path_layers.c_str(), layers ) ) )
		{
			// The problem in the layers file has been reported with its own path;
			// this explains why the collider wasn't built either
			OutputErrorMessageWithFileInfo( m_path_source, "The collider can't be built until the errors in the layers file \"%s\" are fixed",
				path_layers.c_str() );
			return result;
		}
	}
	// Read the human-readable collider file
	Collision::ColliderFormats::sCollider collider;
	if ( !( result = LoadHumanReadableCollider( m_path_source, layers, collider ) ) )
	{
		return result;
	}
	// Write the binary file that the game loads
	if ( !( result = WriteBinaryCollider( m_path_target, collider ) ) )
	{
		return result;
	}

	return result;
}

// Helper Definitions
//===================

namespace
{
	eae6320::cResult FindLayersFile( const char* const i_path_collider, std::string& o_path_layers )
	{
		// The asset build system tells builders where the content directories are with environment variables;
		// like any other asset the game's own file is used if it has one, and the engine's otherwise
		for ( const auto* const environmentVariable : { "GameSourceContentDir", "EngineSourceContentDir" } )
		{
			std::string directory;
			if ( eae6320::Platform::GetEnvironmentVariable( environmentVariable, directory ) )
			{
				const auto path = directory + s_layersRelativePath;
				if ( eae6320::Platform::DoesFileExist( path.c_str() ) )
				{
					o_path_layers = path;
					return eae6320::Results::Success;
				}
			}
		}
		eae6320::Assets::OutputErrorMessageWithFileInfo( i_path_collider, "The game's layers file couldn't be found:"
			" every collider needs %s in the game's content directory (the GameSourceContentDir environment variable)", s_layersRelativePath );
		return eae6320::Results::FileDoesntExist;
	}

	eae6320::cResult WriteBinaryLayers( const char* const i_path, const eae6320::Assets::sCollisionLayers& i_layers )
	{
		// The names are put one after the other (each followed by a 0),
		// and where each one starts is written too, so that the run-time can use them without looking at every character
		std::vector<uint32_t> nameOffsets;
		std::string names;
		for ( const auto& name : i_layers.names )
		{
			nameOffsets.push_back( static_cast<uint32_t>( names.size() ) );
			names += name;
			names.push_back( '\0' );
		}

		std::ofstream fout( i_path, std::ofstream::binary );
		if ( !fout.is_open() )
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, "The built layers file couldn't be opened for writing" );
			return eae6320::Results::Failure;
		}

		// Exactly one write for each of the four pieces of data (see ColliderFormats.h)
		const auto layerCount = static_cast<uint32_t>( i_layers.names.size() );
		fout.write( reinterpret_cast<const char*>( &layerCount ), sizeof( layerCount ) );
		fout.write( reinterpret_cast<const char*>( i_layers.interactionMasks.data() ), sizeof( uint32_t ) * layerCount );
		fout.write( reinterpret_cast<const char*>( nameOffsets.data() ), sizeof( uint32_t ) * layerCount );
		fout.write( names.data(), names.size() );

		fout.close();
		if ( !fout )
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, "The built layers file couldn't be written" );
			return eae6320::Results::Failure;
		}
		return eae6320::Results::Success;
	}

	eae6320::cResult WriteBinaryCollider( const char* const i_path, const eae6320::Collision::ColliderFormats::sCollider& i_collider )
	{
		std::ofstream fout( i_path, std::ofstream::binary );
		if ( !fout.is_open() )
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, "The built collider file couldn't be opened for writing" );
			return eae6320::Results::Failure;
		}

		// The whole collider is a single struct, written in one piece
		fout.write( reinterpret_cast<const char*>( &i_collider ), sizeof( i_collider ) );

		fout.close();
		if ( !fout )
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, "The built collider file couldn't be written" );
			return eae6320::Results::Failure;
		}
		return eae6320::Results::Success;
	}
}

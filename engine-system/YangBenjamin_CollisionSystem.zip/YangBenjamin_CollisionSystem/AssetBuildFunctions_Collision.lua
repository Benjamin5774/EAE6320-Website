--[[
	The collision system's two asset types, to paste into your Tools/AssetBuildLibrary/AssetBuildFunctions.lua

	WHERE TO PASTE IT
	Paste everything below the dashed line into AssetBuildFunctions.lua right after your mesh asset type
	(the NewAssetTypeInfo( "meshes", ... ) block), before the line "-- Local Function Definitions".
	It uses NewAssetTypeInfo(), RegisterAssetToBeBuilt() and FindSourceContentAbsolutePathFromRelativePath(),
	which are local functions that are defined higher up in that file,
	so it has to come after them (anywhere after the shader and mesh asset types is fine, including the very end of the file;
	pasted at the top, the asset build fails with "attempt to call a nil value (global 'NewAssetTypeInfo')").

	Nothing else in AssetBuildFunctions.lua needs to change.
	Then list your files in AssetsToBuild.lua (see ExampleContent/AssetsToBuild_Collision.lua).
]]

----------------------------------------------------------------------------------------------------

-- Collision Asset Types
------------------------

-- ColliderBuilder.exe builds both of the collision system's file types:
--	* the game's layers file (Collision/game.layers -> Collision/game.binlayers)
--	* collider files (e.g. Colliders/player.collider -> Colliders/player.bincollider)
-- A collider names its layer, and ColliderBuilder turns that name into the layer's index using the game's layers file,
-- so that file is always at the same path in the game's content directory
local collisionLayersRelativePath = "Collision/game.layers"

NewAssetTypeInfo( "collisionlayers",
	{
		ConvertSourceRelativePathToBuiltRelativePath = function( i_sourceRelativePath )
			local relativeDirectory, file = i_sourceRelativePath:match( "(.-)([^/\\]+)$" )
			local fileName = file:match( "([^%.]+)" )
			return relativeDirectory .. fileName .. ".binlayers"
		end,
		GetBuilderRelativePath = function()
			return "ColliderBuilder.exe"
		end,
	}
)

NewAssetTypeInfo( "colliders",
	{
		ConvertSourceRelativePathToBuiltRelativePath = function( i_sourceRelativePath )
			local relativeDirectory, file = i_sourceRelativePath:match( "(.-)([^/\\]+)$" )
			local fileName = file:match( "([^%.]+)" )
			return relativeDirectory .. fileName .. ".bincollider"
		end,
		GetBuilderRelativePath = function()
			return "ColliderBuilder.exe"
		end,
		RegisterReferencedAssets = function( i_sourceRelativePath )
			-- Every collider uses the game's layers file (and the game loads it before any collider),
			-- so it is built whenever any collider is
			RegisterAssetToBeBuilt( collisionLayersRelativePath, "collisionlayers" )
		end,
		ShouldTargetBeBuilt = function( i_lastWriteTime_builtAsset )
			-- A built collider stores the index of its layer,
			-- so it has to be built again whenever the layers file changes
			-- (if the layers file doesn't exist the collider's build reports that)
			local path_layers = FindSourceContentAbsolutePathFromRelativePath( collisionLayersRelativePath )
			if path_layers then
				return GetLastWriteTime( path_layers ) > i_lastWriteTime_builtAsset
			else
				return true
			end
		end,
	}
)

# Collision System for the EAE 6320 engine

Benjamin Yang, EAE 6320, Fall 2026 (version 1.0)

Spheres and axis-aligned boxes described in small Lua files, layers that decide what touches what, a solid response that keeps moving objects out of walls and floors, triggers, `OnEnter` / `OnStay` / `OnExit` events, and raycasts. It is not a physics engine: you keep moving your objects with `sRigidBodyState` the way you always have, and the system keeps them out of each other and tells you what touched what.

**The full documentation is `Engine/Collision/UserGuide.md`** (also online: https://game6320-website.netlify.app/engine-system/guide.html). Start with its section 2.

## What is in this ZIP

| Folder or file | What it is |
|---|---|
| `Engine/Collision/` | The run-time static library. Your game includes `Collision.h` only. |
| `Tools/ColliderBuilder/` | The builder for `.layers` and `.collider` files (built like MeshBuilder). |
| `AssetBuildFunctions_Collision.lua` | The two asset types to paste into your `Tools/AssetBuildLibrary/AssetBuildFunctions.lua`. |
| `ExampleContent/` | An example layers file, six example collider files, and the lines for `AssetsToBuild.lua`. |

Nothing in this ZIP replaces a file that you already have. It only uses engine code from Assignment 01, so nothing in Graphics, your meshes or your effects changes.

## Setup (once, about ten minutes)

1. Copy `Engine\Collision` into your solution's `Engine` folder and `Tools\ColliderBuilder` into its `Tools` folder.
2. Visual Studio: right-click the **Engine** solution folder > **Add > Existing Project...** > `Engine\Collision\Collision.vcxproj`, and right-click the **Tools** folder > **Add > Existing Project...** > `Tools\ColliderBuilder\ColliderBuilder.vcxproj`.
3. Right-click your game project > **Add > Reference...** > tick **Collision**.
4. Right-click **BuildMyGameAssets** > **Build Dependencies > Project Dependencies...** > tick **ColliderBuilder**.
5. Open `Tools\AssetBuildLibrary\AssetBuildFunctions.lua` and paste everything below the dashed line of `AssetBuildFunctions_Collision.lua` **right after your mesh asset type** (before `-- Local Function Definitions`; the very end of the file works too, but the top of the file doesn't).
6. Copy `ExampleContent\Collision` and `ExampleContent\Colliders` into `MyGame_\Content`, and add the two tables from `ExampleContent\AssetsToBuild_Collision.lua` to your `AssetsToBuild.lua`.
7. Build the solution. `data\Collision\game.binlayers` and `data\Colliders\*.bincollider` appear next to your other built assets.
8. Add the code to your game:

```cpp
#include <Engine/Collision/Collision.h>

// (here m_player is a game object with a Physics::sRigidBodyState rigidBodyState
// and a Collision::cCollider* collider = nullptr member)

// Initialize(): the system first, then a collider for every object that needs one
if ( !( result = Collision::Initialize( "data/Collision/game.binlayers" ) ) )
	return result;
if ( !( result = Collision::cCollider::Load( "data/Colliders/player.bincollider", m_player.rigidBodyState, m_player.collider ) ) )
	return result;
m_player.collider->OnEnter = [this]( const Collision::sContact& i_contact ) { /* i_contact.other, .normal, .penetrationDepth */ };

// UpdateSimulationBasedOnTime(): move everything as usual, then
Collision::Update();

// CleanUp(): release every collider, then
m_player.collider->DecrementReferenceCount();
Collision::CleanUp();
```

The one rule to remember: a collider keeps a pointer to the rigid body that you gave it, so that rigid body must not move in memory while the collider exists (a member of your game or a fixed array is fine, a growing `std::vector` of objects is not).

When the game starts, `eae6320.log` lists your layers and what each of them touches. If anything goes wrong, the guide's troubleshooting section (13) lists the messages you might see and what they mean.

I tested these steps on a clean copy of my Assignment 08 solution: all four configurations built with no warnings and the game ran with colliders on the first try. If you use the system, I'd love to hear about it, and I'm happy to help on Slack or by email.

/*
	The tests that decide whether two shapes touch, and whether a ray hits a shape

	These are used by Collision::Update() for every pair of colliders that could touch
	and by Collision::Raycast() for every collider that a ray could hit;
	games don't need to call them, but they only depend on the math library
	and can be used on their own (e.g. to test a shape that has no collider).
*/

#ifndef EAE6320_COLLISION_INTERSECTIONS_H
#define EAE6320_COLLISION_INTERSECTIONS_H

// Includes
//=========

#include "ColliderFormats.h"

#include <Engine/Math/sVector.h>

// Interface
//==========

namespace eae6320
{
	namespace Collision
	{
		namespace Intersections
		{
			// Shapes that are closer than this count as touching
			// (so that two objects that rest exactly against each other don't flicker between touching and not touching
			// because of floating point error)
			constexpr float TouchTolerance = 1.0e-3f;

			// A shape in world space
			struct sShape
			{
				Math::sVector center;
				// The half size of a box, or the radius in every component for a sphere
				Math::sVector halfSize;
				// The radius of a sphere
				float radius = 0.0f;
				eShape shape = eShape::Sphere;
			};

			// Returns true if the two shapes overlap or are within TouchTolerance of each other.
			// If they do:
			//	* o_normal is a unit vector pointing from i_b toward i_a
			//		along the direction in which the shapes overlap the least
			//		(moving i_a by o_normal * o_penetrationDepth would separate them)
			//	* o_penetrationDepth is how far they overlap along o_normal (never negative)
			// Boxes are axis-aligned.
			bool DoShapesTouch( const sShape& i_a, const sShape& i_b, Math::sVector& o_normal, float& o_penetrationDepth );

			// Returns true if a ray that starts at i_origin and goes in i_direction (which must be a unit vector)
			// hits the shape no farther than i_maxDistance from its origin.
			// A ray that starts inside the shape (or exactly on its surface) doesn't hit it.
			// If it does hit:
			//	* o_distance is how far from i_origin the ray enters the shape
			//	* o_normal is the unit normal of the shape's surface where the ray enters it
			//		(it points out of the shape, back toward the side that the ray came from)
			// Boxes are axis-aligned.
			bool DoesRayHitShape( const Math::sVector& i_origin, const Math::sVector& i_direction, const float i_maxDistance,
				const sShape& i_shape, float& o_distance, Math::sVector& o_normal );
		}
	}
}

#endif	// EAE6320_COLLISION_INTERSECTIONS_H

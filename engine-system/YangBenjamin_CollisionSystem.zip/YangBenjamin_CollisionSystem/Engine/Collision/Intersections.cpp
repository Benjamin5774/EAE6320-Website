// Includes
//=========

#include "Intersections.h"

#include <algorithm>
#include <cmath>
#include <Engine/Asserts/Asserts.h>
#include <utility>

// Helper Declarations
//====================

namespace
{
	// Each test is written for one combination of shapes.
	// The normal always points from the second shape toward the first one.
	bool DoSpheresTouch( const eae6320::Collision::Intersections::sShape& i_a, const eae6320::Collision::Intersections::sShape& i_b,
		eae6320::Math::sVector& o_normal, float& o_penetrationDepth );
	bool DoesSphereTouchBox( const eae6320::Collision::Intersections::sShape& i_sphere, const eae6320::Collision::Intersections::sShape& i_box,
		eae6320::Math::sVector& o_normal, float& o_penetrationDepth );
	bool DoBoxesTouch( const eae6320::Collision::Intersections::sShape& i_a, const eae6320::Collision::Intersections::sShape& i_b,
		eae6320::Math::sVector& o_normal, float& o_penetrationDepth );

	// Each ray test is written for one shape (the direction is a unit vector)
	bool DoesRayHitSphere( const eae6320::Math::sVector& i_origin, const eae6320::Math::sVector& i_direction, const float i_maxDistance,
		const eae6320::Collision::Intersections::sShape& i_sphere, float& o_distance, eae6320::Math::sVector& o_normal );
	bool DoesRayHitBox( const eae6320::Math::sVector& i_origin, const eae6320::Math::sVector& i_direction, const float i_maxDistance,
		const eae6320::Collision::Intersections::sShape& i_box, float& o_distance, eae6320::Math::sVector& o_normal );

	// Below this distance two points are treated as the same point
	// (a direction can't be calculated from the difference between them)
	constexpr float s_minDistance = 1.0e-6f;

	// Returns the index (0 = x, 1 = y, 2 = z) of the smallest of three values
	int GetIndexOfSmallest( const float* const i_values );
	// Returns the unit vector along the x, y or z axis, pointing in the direction of the sign of i_direction (+ for 0)
	eae6320::Math::sVector GetUnitAxis( const int i_axisIndex, const float i_direction );
}

// Interface
//==========

bool eae6320::Collision::Intersections::DoShapesTouch( const sShape& i_a, const sShape& i_b,
	Math::sVector& o_normal, float& o_penetrationDepth )
{
	// Quick rejection:
	// if the bounding boxes don't touch then the shapes can't either
	// (most pairs in a game are far apart, and this is much cheaper than any of the exact tests)
	{
		const auto offset = i_a.center - i_b.center;
		if ( ( std::abs( offset.x ) > ( i_a.halfSize.x + i_b.halfSize.x + TouchTolerance ) )
			|| ( std::abs( offset.y ) > ( i_a.halfSize.y + i_b.halfSize.y + TouchTolerance ) )
			|| ( std::abs( offset.z ) > ( i_a.halfSize.z + i_b.halfSize.z + TouchTolerance ) ) )
		{
			return false;
		}
	}

	// The exact test depends on the two shapes
	if ( i_a.shape == eShape::Sphere )
	{
		if ( i_b.shape == eShape::Sphere )
		{
			return DoSpheresTouch( i_a, i_b, o_normal, o_penetrationDepth );
		}
		else
		{
			EAE6320_ASSERT( i_b.shape == eShape::Box );
			return DoesSphereTouchBox( i_a, i_b, o_normal, o_penetrationDepth );
		}
	}
	else
	{
		EAE6320_ASSERT( i_a.shape == eShape::Box );
		if ( i_b.shape == eShape::Sphere )
		{
			// The sphere-box test is written from the sphere's point of view,
			// so its normal points toward the sphere (i_b) and has to be turned around
			const auto doTheyTouch = DoesSphereTouchBox( i_b, i_a, o_normal, o_penetrationDepth );
			o_normal = -o_normal;
			return doTheyTouch;
		}
		else
		{
			EAE6320_ASSERT( i_b.shape == eShape::Box );
			return DoBoxesTouch( i_a, i_b, o_normal, o_penetrationDepth );
		}
	}
}

bool eae6320::Collision::Intersections::DoesRayHitShape( const Math::sVector& i_origin, const Math::sVector& i_direction, const float i_maxDistance,
	const sShape& i_shape, float& o_distance, Math::sVector& o_normal )
{
	EAE6320_ASSERTF( std::abs( Math::Dot( i_direction, i_direction ) - 1.0f ) < 1.0e-3f, "A ray's direction must be a unit vector" );
	if ( i_shape.shape == eShape::Sphere )
	{
		return DoesRayHitSphere( i_origin, i_direction, i_maxDistance, i_shape, o_distance, o_normal );
	}
	else
	{
		EAE6320_ASSERT( i_shape.shape == eShape::Box );
		return DoesRayHitBox( i_origin, i_direction, i_maxDistance, i_shape, o_distance, o_normal );
	}
}

// Helper Definitions
//===================

namespace
{
	bool DoSpheresTouch( const eae6320::Collision::Intersections::sShape& i_a, const eae6320::Collision::Intersections::sShape& i_b,
		eae6320::Math::sVector& o_normal, float& o_penetrationDepth )
	{
		// Two spheres touch if their centers are no farther apart than the sum of their radii
		// (the squared distance is compared first so that the square root is only needed for spheres that touch)
		const auto offset = i_a.center - i_b.center;
		const auto distanceSquared = eae6320::Math::Dot( offset, offset );
		const auto radiusSum = i_a.radius + i_b.radius;
		const auto maxDistance = radiusSum + eae6320::Collision::Intersections::TouchTolerance;
		if ( distanceSquared > ( maxDistance * maxDistance ) )
		{
			return false;
		}
		const auto distance = std::sqrt( distanceSquared );
		// They are separated fastest along the line between the centers
		// (if the centers are in the same place every direction is as good as any other, and up is chosen)
		o_normal = ( distance > s_minDistance ) ? ( offset * ( 1.0f / distance ) ) : eae6320::Math::sVector( 0.0f, 1.0f, 0.0f );
		o_penetrationDepth = std::max( radiusSum - distance, 0.0f );
		return true;
	}

	bool DoesSphereTouchBox( const eae6320::Collision::Intersections::sShape& i_sphere, const eae6320::Collision::Intersections::sShape& i_box,
		eae6320::Math::sVector& o_normal, float& o_penetrationDepth )
	{
		// Find the point of the box that is closest to the sphere's center
		// (each coordinate of the center clamped to the box)
		const auto boxMin = i_box.center - i_box.halfSize;
		const auto boxMax = i_box.center + i_box.halfSize;
		const eae6320::Math::sVector closestPoint(
			std::clamp( i_sphere.center.x, boxMin.x, boxMax.x ),
			std::clamp( i_sphere.center.y, boxMin.y, boxMax.y ),
			std::clamp( i_sphere.center.z, boxMin.z, boxMax.z ) );
		const auto offset = i_sphere.center - closestPoint;
		const auto distanceSquared = eae6320::Math::Dot( offset, offset );
		if ( distanceSquared > ( s_minDistance * s_minDistance ) )
		{
			// The center is outside of the box:
			// the sphere touches the box if that closest point is inside the sphere
			const auto maxDistance = i_sphere.radius + eae6320::Collision::Intersections::TouchTolerance;
			if ( distanceSquared > ( maxDistance * maxDistance ) )
			{
				return false;
			}
			const auto distance = std::sqrt( distanceSquared );
			o_normal = offset * ( 1.0f / distance );
			o_penetrationDepth = std::max( i_sphere.radius - distance, 0.0f );
			return true;
		}
		else
		{
			// The center is inside of the box (or on its surface):
			// the sphere would have to leave through the face that is nearest to its center
			const auto offset_fromBoxCenter = i_sphere.center - i_box.center;
			const float offsets[] = { offset_fromBoxCenter.x, offset_fromBoxCenter.y, offset_fromBoxCenter.z };
			const float distancesToFaces[] =
			{
				i_box.halfSize.x - std::abs( offset_fromBoxCenter.x ),
				i_box.halfSize.y - std::abs( offset_fromBoxCenter.y ),
				i_box.halfSize.z - std::abs( offset_fromBoxCenter.z ),
			};
			const auto axisIndex = GetIndexOfSmallest( distancesToFaces );
			o_normal = GetUnitAxis( axisIndex, offsets[axisIndex] );
			o_penetrationDepth = i_sphere.radius + std::max( distancesToFaces[axisIndex], 0.0f );
			return true;
		}
	}

	bool DoBoxesTouch( const eae6320::Collision::Intersections::sShape& i_a, const eae6320::Collision::Intersections::sShape& i_b,
		eae6320::Math::sVector& o_normal, float& o_penetrationDepth )
	{
		// Two axis-aligned boxes touch if they overlap along all three axes
		const auto offset = i_a.center - i_b.center;
		const float offsets[] = { offset.x, offset.y, offset.z };
		// (a negative overlap is a gap)
		const float overlaps[] =
		{
			( i_a.halfSize.x + i_b.halfSize.x ) - std::abs( offset.x ),
			( i_a.halfSize.y + i_b.halfSize.y ) - std::abs( offset.y ),
			( i_a.halfSize.z + i_b.halfSize.z ) - std::abs( offset.z ),
		};
		const auto axisIndex = GetIndexOfSmallest( overlaps );
		if ( overlaps[axisIndex] < -eae6320::Collision::Intersections::TouchTolerance )
		{
			return false;
		}
		// They are separated fastest along the axis where they overlap the least
		o_normal = GetUnitAxis( axisIndex, offsets[axisIndex] );
		o_penetrationDepth = std::max( overlaps[axisIndex], 0.0f );
		return true;
	}

	bool DoesRayHitSphere( const eae6320::Math::sVector& i_origin, const eae6320::Math::sVector& i_direction, const float i_maxDistance,
		const eae6320::Collision::Intersections::sShape& i_sphere, float& o_distance, eae6320::Math::sVector& o_normal )
	{
		// A point on the ray is i_origin + ( i_direction * t ), and it is on the sphere's surface when
		// its distance from the center is the radius.
		// Squaring both sides gives a quadratic equation in t (the "a" term is 1 because the direction is a unit vector):
		//	t^2 + 2bt + c = 0, where b = Dot( m, i_direction ), c = Dot( m, m ) - radius^2, and m = i_origin - center
		const auto m = i_origin - i_sphere.center;
		const auto b = eae6320::Math::Dot( m, i_direction );
		const auto c = eae6320::Math::Dot( m, m ) - ( i_sphere.radius * i_sphere.radius );
		// A ray that starts inside the sphere (or on it) doesn't hit it,
		// and neither does one that starts outside and points away from it
		if ( ( c <= 0.0f ) || ( b > 0.0f ) )
		{
			return false;
		}
		// If the quadratic has no real solution then the ray's line misses the sphere
		const auto discriminant = ( b * b ) - c;
		if ( discriminant < 0.0f )
		{
			return false;
		}
		// The smaller solution is where the ray enters the sphere
		// (it can't be negative here, because the origin is outside and the ray points toward the sphere)
		const auto distance = -b - std::sqrt( discriminant );
		if ( distance > i_maxDistance )
		{
			return false;
		}
		o_distance = std::max( distance, 0.0f );
		const auto point = i_origin + ( i_direction * o_distance );
		// The normal of a sphere at a point on its surface points from the center through that point
		o_normal = ( point - i_sphere.center ) * ( 1.0f / i_sphere.radius );
		return true;
	}

	bool DoesRayHitBox( const eae6320::Math::sVector& i_origin, const eae6320::Math::sVector& i_direction, const float i_maxDistance,
		const eae6320::Collision::Intersections::sShape& i_box, float& o_distance, eae6320::Math::sVector& o_normal )
	{
		// The "slab" method:
		// an axis-aligned box is where three slabs (the space between two parallel planes) overlap,
		// so the ray is inside the box between the time it has entered all three slabs and the time it leaves the first one
		const auto boxMin = i_box.center - i_box.halfSize;
		const auto boxMax = i_box.center + i_box.halfSize;
		const float origins[] = { i_origin.x, i_origin.y, i_origin.z };
		const float directions[] = { i_direction.x, i_direction.y, i_direction.z };
		const float mins[] = { boxMin.x, boxMin.y, boxMin.z };
		const float maxs[] = { boxMax.x, boxMax.y, boxMax.z };
		// Only the part of the ray between its origin and i_maxDistance counts
		float distance_enter = 0.0f;
		float distance_exit = i_maxDistance;
		// The axis of the face where the ray enters the box
		// (if it is still -1 at the end then the ray started inside the box, or on its surface)
		int axisIndex_enter = -1;
		for ( int i = 0; i < 3; ++i )
		{
			if ( std::abs( directions[i] ) < s_minDistance )
			{
				// A ray that is parallel to a slab is either always inside of it or never
				if ( ( origins[i] < mins[i] ) || ( origins[i] > maxs[i] ) )
				{
					return false;
				}
			}
			else
			{
				// Where the ray crosses the two planes of this slab
				const auto oneOverDirection = 1.0f / directions[i];
				auto distance_near = ( mins[i] - origins[i] ) * oneOverDirection;
				auto distance_far = ( maxs[i] - origins[i] ) * oneOverDirection;
				if ( distance_near > distance_far )
				{
					std::swap( distance_near, distance_far );
				}
				if ( distance_near > distance_enter )
				{
					distance_enter = distance_near;
					axisIndex_enter = i;
				}
				distance_exit = std::min( distance_exit, distance_far );
				// If the ray leaves one slab before it has entered all of them then it misses the box
				// (or the box is farther away than i_maxDistance)
				if ( distance_enter > distance_exit )
				{
					return false;
				}
			}
		}
		if ( axisIndex_enter < 0 )
		{
			return false;
		}
		o_distance = distance_enter;
		// The face where the ray enters faces back toward the ray
		o_normal = GetUnitAxis( axisIndex_enter, -directions[axisIndex_enter] );
		return true;
	}

	int GetIndexOfSmallest( const float* const i_values )
	{
		int smallestIndex = 0;
		if ( i_values[1] < i_values[smallestIndex] )
		{
			smallestIndex = 1;
		}
		if ( i_values[2] < i_values[smallestIndex] )
		{
			smallestIndex = 2;
		}
		return smallestIndex;
	}

	eae6320::Math::sVector GetUnitAxis( const int i_axisIndex, const float i_direction )
	{
		const auto sign = ( i_direction >= 0.0f ) ? 1.0f : -1.0f;
		switch ( i_axisIndex )
		{
		case 0: return eae6320::Math::sVector( sign, 0.0f, 0.0f );
		case 1: return eae6320::Math::sVector( 0.0f, sign, 0.0f );
		default: return eae6320::Math::sVector( 0.0f, 0.0f, sign );
		}
	}
}

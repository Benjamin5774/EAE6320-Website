/*
	The binary formats that ColliderBuilder writes and the Collision library reads

	Games never need to look inside these files:
	they write the human-readable files (*.collider and the game's *.layers file, see the user guide),
	ColliderBuilder checks them and writes these binary files at build time,
	and the run-time loads each binary file in a few steps without parsing or converting anything.

	The same files are built for every platform that we have
	(they only contain floats and small integers, and both platforms are little-endian);
	if a platform ever needed something different the builder is where it would change.
*/

#ifndef EAE6320_COLLISION_COLLIDERFORMATS_H
#define EAE6320_COLLISION_COLLIDERFORMATS_H

// Includes
//=========

#include <cstdint>
#include <Engine/Math/sVector.h>
#include <type_traits>

// Interface
//==========

namespace eae6320
{
	namespace Collision
	{
		// The shapes that a collider can have
		enum class eShape : uint8_t
		{
			Sphere,
			Box,	// Axis-aligned: it doesn't rotate with its object

			Count
		};

		// A game can have at most this many layers
		// (which layers touch each other is stored as one bit per layer)
		constexpr unsigned int MaxLayerCount = 32;

		namespace ColliderFormats
		{
			// The bits of sCollider::flags
			namespace Flags
			{
				// A trigger reports overlaps but never pushes anything
				constexpr uint8_t IsTrigger = 1 << 0;
				// A static collider never moves (walls, floors);
				// two static colliders are never tested against each other
				constexpr uint8_t IsStatic = 1 << 1;

				constexpr uint8_t All = IsTrigger | IsStatic;
			}

			// A built collider file (*.bincollider) is exactly one of these
			struct sCollider
			{
				// The center of the shape, relative to the position of the rigid body that the collider is attached to
				Math::sVector center;
				// Half the size of the shape along each axis
				// (a box's half size; for a sphere every component is the radius,
				// so center +/- halfSize is the bounding box of either shape)
				Math::sVector halfSize;
				// The radius of a sphere (0 for a box)
				float radius = 0.0f;
				eShape shape = eShape::Sphere;
				// The index of the collider's layer in the layers file that the collider was built with
				uint8_t layer = 0;
				// Any combination of the Flags above
				uint8_t flags = 0;
				// (always 0; it only makes the padding at the end of the struct explicit)
				uint8_t unused = 0;
			};
			static_assert( sizeof( sCollider ) == 32, "A built collider file is expected to be exactly 32 bytes" );
			static_assert( std::is_trivially_copyable_v<sCollider>, "A collider has to be copyable as raw bytes" );

			// A built layers file (*.binlayers) is these four pieces, in this order:
			//	uint32_t	layerCount	(1 to MaxLayerCount)
			//	uint32_t	interactionMasks[layerCount]	(bit b of interactionMasks[a] is set if layers a and b touch each other)
			//	uint32_t	nameOffsets[layerCount]	(where each layer's name starts, counted from the first name)
			//	char	names[]	(the rest of the file: every layer's name followed by a 0, one after the other)
			// The names are kept so that a game can look layers up by name at run time (e.g. Collision::GetLayerMask( "world" )).
		}
	}
}

#endif	// EAE6320_COLLISION_COLLIDERFORMATS_H

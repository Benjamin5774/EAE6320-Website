// Includes
//=========

#include "cCollider.h"

#include "cWorld.h"

#include <cmath>
#include <cstring>
#include <Engine/Asserts/Asserts.h>
#include <Engine/Logging/Logging.h>
#include <Engine/Physics/sRigidBodyState.h>
#include <Engine/Platform/Platform.h>
#include <new>
#include <string>

// Interface
//==========

// Factory
//--------

eae6320::cResult eae6320::Collision::cCollider::Load( const char* const i_path, Physics::sRigidBodyState& io_rigidBody, cCollider*& o_collider )
{
	auto result = Results::Success;

	o_collider = nullptr;

	// The collider's layer has to be checked against the game's layers
	if ( !Internal::cWorld::IsInitialized() )
	{
		result = Results::Failure;
		EAE6320_ASSERTF( false, "Collision::Initialize() must be called before any collider is loaded" );
		Logging::OutputError( "The collider \"%s\" can't be loaded because Collision::Initialize() hasn't been called", i_path );
		return result;
	}

	// Load the built file
	// (it is exactly one sCollider, so it is copied out in one step)
	ColliderFormats::sCollider colliderData;
	{
		Platform::sDataFromFile dataFromFile;
		{
			std::string errorMessage;
			if ( !( result = Platform::LoadBinaryFile( i_path, dataFromFile, &errorMessage ) ) )
			{
				EAE6320_ASSERTF( false, "Couldn't load the collider file \"%s\": %s", i_path, errorMessage.c_str() );
				Logging::OutputError( "Failed to load the collider file \"%s\": %s", i_path, errorMessage.c_str() );
				return result;
			}
		}
		if ( dataFromFile.size != sizeof( colliderData ) )
		{
			result = Results::InvalidFile;
			EAE6320_ASSERTF( false, "The collider file \"%s\" is invalid", i_path );
			Logging::OutputError( "The collider file \"%s\" is %zu bytes, but a built collider is always %zu bytes",
				i_path, dataFromFile.size, sizeof( colliderData ) );
			return result;
		}
		std::memcpy( &colliderData, dataFromFile.data, sizeof( colliderData ) );
	}
	// Check it
	// (ColliderBuilder has already checked the human-readable file,
	// but a built file could be damaged, or out of date if the layers have changed since it was built)
	{
		const char* problem = nullptr;
		const auto isFinite = []( const Math::sVector& i_vector )
		{
			return std::isfinite( i_vector.x ) && std::isfinite( i_vector.y ) && std::isfinite( i_vector.z );
		};
		if ( colliderData.shape >= eShape::Count )
		{
			problem = "its shape is unknown";
		}
		// (the comparisons are written so that NaN fails them)
		else if ( !( colliderData.halfSize.x > 0.0f ) || !( colliderData.halfSize.y > 0.0f ) || !( colliderData.halfSize.z > 0.0f )
			|| !isFinite( colliderData.halfSize ) || !isFinite( colliderData.center ) )
		{
			problem = "its size or its center isn't valid";
		}
		else if ( ( colliderData.shape == eShape::Sphere ) && !( colliderData.radius > 0.0f ) )
		{
			problem = "it is a sphere without a valid radius";
		}
		else if ( colliderData.layer >= Internal::cWorld::GetLayerCount() )
		{
			problem = "its layer isn't in the game's layers file (it was built with a different layers file: build the game's assets again)";
		}
		else if ( ( colliderData.flags & ~ColliderFormats::Flags::All ) != 0 )
		{
			problem = "it has unknown flags";
		}
		if ( problem )
		{
			result = Results::InvalidFile;
			EAE6320_ASSERTF( false, "The collider file \"%s\" is invalid: %s", i_path, problem );
			Logging::OutputError( "The collider file \"%s\" is invalid: %s", i_path, problem );
			return result;
		}
	}

	// Create the collider (it starts with a reference count of 1, which the caller gets)
	auto* const newCollider = new (std::nothrow) cCollider( colliderData, io_rigidBody );
	if ( !newCollider )
	{
		result = Results::OutOfMemory;
		EAE6320_ASSERTF( false, "Couldn't allocate memory for the collider \"%s\"", i_path );
		Logging::OutputError( "Failed to allocate memory for the collider \"%s\"", i_path );
		return result;
	}
	// Add it to the world (which takes a reference of its own)
	Internal::cWorld::Add( *newCollider );

	o_collider = newCollider;
	return result;
}

// Access
//-------

eae6320::Math::sVector eae6320::Collision::cCollider::GetCenter() const
{
	return m_rigidBody->position + m_data.center;
}

// Implementation
//===============

// Initialize / Clean Up
//----------------------

eae6320::Collision::cCollider::cCollider( const ColliderFormats::sCollider& i_data, Physics::sRigidBodyState& io_rigidBody )
	:
	m_data( i_data ), m_rigidBody( &io_rigidBody )
{

}

eae6320::Collision::cCollider::~cCollider()
{
	EAE6320_ASSERT( m_referenceCount == 0 );
}

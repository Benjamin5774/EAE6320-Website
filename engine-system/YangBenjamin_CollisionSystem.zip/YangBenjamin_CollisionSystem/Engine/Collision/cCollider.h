/*
	A collider gives a game object a shape that the collision system knows about

	HOW TO USE ONE
	--------------
	1. Write a collider file (e.g. Content/Colliders/player.collider) and list it in AssetsToBuild.lua
		(see the user guide for every value the file can have).
	2. In your game's Initialize() load the built file and attach it to the rigid body of the object it belongs to:
			Collision::cCollider* collider;
			Collision::cCollider::Load( "data/Colliders/player.bincollider", m_player.rigidBodyState, collider );
		The collider follows the rigid body: its center is always the rigid body's position plus the offset from the file.
		The rigid body must stay where it is in memory for as long as the collider exists
		(a member of your game or of a game object is fine; an element of a std::vector that can grow is not).
	3. Give it any of the event functions below (a lambda is easiest) and, if you like, a pointer to your own object:
			collider->userData = &m_player;
			collider->OnEnter = [this]( const Collision::sContact& i_contact ) { ... };
	4. Call Collision::Update() once per simulation update, after your objects have moved.
		That is when the events are sent.
	5. When the object goes away give up the reference: collider->DecrementReferenceCount().

	LIFETIME
	--------
	Colliders are reference counted like meshes and effects: Load() gives you one reference.
	While a collider is in the world the collision system keeps a reference of its own,
	so a collider (and the "other" collider in a contact) never disappears in the middle of an Update(),
	even if you release it from inside an event.
	The next time the system can do it safely it removes the released collider from the world,
	sends OnExit to everything that it was still touching, and deletes it.
	A collider that you have released never gets any more events (whatever its functions refer to might be gone).

	EVENTS
	------
	Every Update() finds the pairs of colliders that touch (they overlap or are within a hair of each other).
	For each pair both colliders are told, each from its own point of view:
		* OnEnter: the first update in which the pair touches
		* OnStay: every following update in which it still touches
		* OnExit: the first update in which it doesn't touch any more
			(because the colliders moved apart, one of them was disabled, or one of them was released)
	All of the exits are sent first, then the enters, then the stays.
	The events describe what Update() found; anything that you change from inside an event
	(moving an object, disabling a collider, ...) is taken into account by the next Update().

	Only colliders whose layers interact touch each other (that is what the layers file says),
	and two static colliders are never tested against each other.

	RESPONSE
	--------
	Before it sends the events Update() also keeps solid colliders from overlapping
	(a collider is solid unless it is a trigger, and "dynamic" if it isn't static):
		* A dynamic collider that overlaps a static one is moved all of the way out along the contact normal,
			and the part of its rigid body's velocity that points into the static collider is removed.
			That is what lets an object stand on a floor, stop at a wall and slide along it,
			without bouncing and without sinking in.
		* Two dynamic colliders are each moved half of the way, and the speed at which they were approaching each other
			is removed from both equally (as if they had the same mass).
		* Triggers never push anything and are never pushed.
	Only the position and the velocity of the rigid body are changed (never its acceleration or orientation),
	and only when the layers of the two colliders interact.
	The contacts that the events get describe the overlap as Update() found it, before it was resolved:
	penetrationDepth is how far the colliders had sunk into each other.

	Detection only happens once per simulation update, so a small, fast object can pass through a thin collider
	if it moves farther than about its own size in one update ("tunneling");
	make walls and floors thick, or update the simulation more often (see GetSimulationUpdatePeriod_inSeconds()).
*/

#ifndef EAE6320_COLLISION_CCOLLIDER_H
#define EAE6320_COLLISION_CCOLLIDER_H

// Includes
//=========

#include "ColliderFormats.h"

#include <cstdint>
#include <Engine/Assets/ReferenceCountedAssets.h>
#include <Engine/Math/sVector.h>
#include <Engine/Results/Results.h>
#include <functional>

// Forward Declarations
//=====================

namespace eae6320
{
	namespace Collision
	{
		class cCollider;

		namespace Internal
		{
			// The collision system's bookkeeping (see cWorld.h); games never use it directly
			class cWorld;
		}
	}

	namespace Physics
	{
		struct sRigidBodyState;
	}
}

// Struct Declaration
//===================

namespace eae6320
{
	namespace Collision
	{
		// What an event tells a collider about the collider that it touched
		struct sContact
		{
			// The other collider
			// (it is valid until the event function returns;
			// call IncrementReferenceCount() on it if you want to keep it for longer)
			cCollider* other = nullptr;
			// A unit vector pointing from the other collider toward this one, along the direction in which they overlap the least:
			// moving this collider by normal * penetrationDepth would separate them.
			// It is the zero vector in OnExit (the colliders don't overlap any more).
			Math::sVector normal;
			// How far the two colliders overlap along the normal
			// (0 when they are only just touching, and always 0 in OnExit)
			float penetrationDepth = 0.0f;
		};
	}
}

// Class Declaration
//==================

namespace eae6320
{
	namespace Collision
	{
		class cCollider
		{
			// Interface
			//==========

		public:

			// Factory
			//--------

			// Loads a collider file built by ColliderBuilder (e.g. "data/Colliders/player.bincollider"),
			// attaches it to the given rigid body and adds it to the world.
			// Collision::Initialize() must have been called first (the collider's layer is checked against the game's layers).
			// On success the caller owns one reference to o_collider; on failure o_collider is nullptr.
			static cResult Load( const char* const i_path, Physics::sRigidBodyState& io_rigidBody, cCollider*& o_collider );

			// Events
			//-------

			// Any of these can be left empty.
			// They are only ever called from Collision::Update(), on the thread that calls it.
			std::function<void( const sContact& i_contact )> OnEnter;
			std::function<void( const sContact& i_contact )> OnStay;
			std::function<void( const sContact& i_contact )> OnExit;

			// The collision system never looks at this;
			// set it to your own object so that you can find out what "other" is inside an event
			void* userData = nullptr;

			// Enabling / Disabling
			//---------------------

			// A disabled collider is skipped by the collision system:
			// whatever it was touching gets an OnExit at the next Update() (and so does the collider itself),
			// and it doesn't touch anything again until it is enabled.
			// Colliders start enabled.
			void SetEnabled( const bool i_isEnabled ) { m_isEnabled = i_isEnabled; }
			bool IsEnabled() const { return m_isEnabled; }

			// Access
			//-------

			eShape GetShape() const { return m_data.shape; }
			// The radius of a sphere (0 for a box)
			float GetRadius() const { return m_data.radius; }
			// Half the size of the shape along each axis (for a sphere every component is the radius)
			Math::sVector GetHalfSize() const { return m_data.halfSize; }
			// The offset of the center from the rigid body's position (from the collider file)
			Math::sVector GetCenterOffset() const { return m_data.center; }
			// Where the center of the shape is in the world right now (the rigid body's position plus the offset)
			Math::sVector GetCenter() const;

			// The index of the collider's layer in the layers file (see Collision::GetLayerName())
			uint8_t GetLayer() const { return m_data.layer; }
			// The collider's layer as a mask with only its layer's bit set
			uint32_t GetLayerMask() const { return uint32_t( 1 ) << m_data.layer; }
			bool IsTrigger() const { return ( m_data.flags & ColliderFormats::Flags::IsTrigger ) != 0; }
			bool IsStatic() const { return ( m_data.flags & ColliderFormats::Flags::IsStatic ) != 0; }

			// The rigid body that the collider follows
			Physics::sRigidBodyState& GetRigidBody() const { return *m_rigidBody; }

			// A number that is different for every collider that has been loaded since the program started
			// (colliders that were loaded earlier have smaller numbers); handy for logging and debugging
			uint32_t GetId() const { return m_id; }

			// Reference Counting
			//-------------------

			EAE6320_ASSETS_DECLAREREFERENCECOUNTINGFUNCTIONS()
			EAE6320_ASSETS_DECLAREDELETEDREFERENCECOUNTEDFUNCTIONS( cCollider )

			// Data
			//=====

		private:

			// Everything that was in the collider file
			ColliderFormats::sCollider m_data;
			// The rigid body that the collider follows (it belongs to the game)
			Physics::sRigidBodyState* m_rigidBody = nullptr;
			// Set by the collision system when the collider is added to the world
			uint32_t m_id = 0;
			bool m_isEnabled = true;
			EAE6320_ASSETS_DECLAREREFERENCECOUNT()

			// Implementation
			//===============

		private:

			// The collision system needs to know whether the game still holds any references
			friend class Internal::cWorld;

			// Initialize / Clean Up
			//----------------------

			cCollider( const ColliderFormats::sCollider& i_data, Physics::sRigidBodyState& io_rigidBody );
			~cCollider();
		};
	}
}

#endif	// EAE6320_COLLISION_CCOLLIDER_H

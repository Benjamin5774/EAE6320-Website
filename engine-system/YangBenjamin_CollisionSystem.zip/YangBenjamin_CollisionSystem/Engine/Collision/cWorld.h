/*
	The collision system's bookkeeping:
	the game's layers, every collider in the world, and which pairs of colliders are touching

	Games never use this directly (Collision.h and cCollider.h are the interface);
	it is a class only so that cCollider can let it see whether the game still holds a collider.
	Everything here is meant to be used from one thread (the one that runs the simulation).
*/

#ifndef EAE6320_COLLISION_CWORLD_H
#define EAE6320_COLLISION_CWORLD_H

// Includes
//=========

#include <cstdint>
#include <Engine/Math/sVector.h>
#include <Engine/Results/Results.h>

// Forward Declarations
//=====================

namespace eae6320
{
	namespace Collision
	{
		class cCollider;
		struct sRaycastHit;
	}
}

// Class Declaration
//==================

namespace eae6320
{
	namespace Collision
	{
		namespace Internal
		{
			class cWorld
			{
				// Interface
				//==========

			public:

				// Initialize / Clean Up
				//----------------------

				static cResult Initialize( const char* const i_path_layers );
				static cResult CleanUp();
				static bool IsInitialized();

				// Update
				//-------

				static void Update();

				// Raycasts
				//---------

				static bool Raycast( const Math::sVector& i_origin, const Math::sVector& i_direction, const float i_maxDistance,
					sRaycastHit& o_hit, const uint32_t i_layerMask, const bool i_shouldTriggersBeHit );

				// Colliders
				//----------

				// Called by cCollider::Load() for every new collider
				// (the world takes a reference of its own, which it gives up when the game has released the collider)
				static void Add( cCollider& io_collider );

				// True if anyone besides the world still holds a reference to the collider
				static bool IsHeldByGame( const cCollider& i_collider );

				// Layers
				//-------

				static unsigned int GetLayerCount();
				static bool GetLayerIndex( const char* const i_layerName, uint8_t& o_layerIndex );
				static const char* GetLayerName( const uint8_t i_layerIndex );
				static bool DoLayersInteract( const uint8_t i_layerA, const uint8_t i_layerB );

				// Implementation
				//===============

			private:

				cWorld() = delete;
			};
		}
	}
}

#endif	// EAE6320_COLLISION_CWORLD_H

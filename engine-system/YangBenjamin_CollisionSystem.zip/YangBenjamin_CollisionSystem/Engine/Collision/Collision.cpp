// Includes
//=========

#include "Collision.h"

#include "cWorld.h"

#include <Engine/Asserts/Asserts.h>
#include <Engine/Logging/Logging.h>

// Interface
//==========

// Initialize / Clean Up
//----------------------

eae6320::cResult eae6320::Collision::Initialize( const char* const i_path_layers )
{
	return Internal::cWorld::Initialize( i_path_layers );
}

eae6320::cResult eae6320::Collision::CleanUp()
{
	return Internal::cWorld::CleanUp();
}

// Update
//-------

void eae6320::Collision::Update()
{
	Internal::cWorld::Update();
}

// Raycasts
//---------

bool eae6320::Collision::Raycast( const Math::sVector& i_origin, const Math::sVector& i_direction, const float i_maxDistance,
	sRaycastHit& o_hit, const uint32_t i_layerMask, const bool i_shouldTriggersBeHit )
{
	return Internal::cWorld::Raycast( i_origin, i_direction, i_maxDistance, o_hit, i_layerMask, i_shouldTriggersBeHit );
}

// Layers
//-------

uint32_t eae6320::Collision::GetLayerMask( const char* const i_layerName )
{
	uint8_t layerIndex;
	if ( Internal::cWorld::GetLayerIndex( i_layerName, layerIndex ) )
	{
		return uint32_t( 1 ) << layerIndex;
	}
	else
	{
		// This is almost always a typo, and a mask of 0 would silently match nothing
		EAE6320_ASSERTF( false, "There is no collision layer named \"%s\"", i_layerName ? i_layerName : "(null)" );
		Logging::OutputError( "Collision::GetLayerMask(): there is no layer named \"%s\" in the layers file (the mask is 0)",
			i_layerName ? i_layerName : "(null)" );
		return 0;
	}
}

bool eae6320::Collision::GetLayerIndex( const char* const i_layerName, uint8_t& o_layerIndex )
{
	return Internal::cWorld::GetLayerIndex( i_layerName, o_layerIndex );
}

const char* eae6320::Collision::GetLayerName( const uint8_t i_layerIndex )
{
	return Internal::cWorld::GetLayerName( i_layerIndex );
}

bool eae6320::Collision::DoLayersInteract( const uint8_t i_layerA, const uint8_t i_layerB )
{
	return Internal::cWorld::DoLayersInteract( i_layerA, i_layerB );
}

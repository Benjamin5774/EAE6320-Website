/*
	The collision system:
	colliders (spheres and axis-aligned boxes) that are attached to game objects,
	solid colliders that keep each other from overlapping (walls stop things, floors hold them up),
	events that tell the game when colliders start touching, keep touching and stop touching,
	and raycasts that find the first collider in a direction

	This is the only header that a game needs to include (it includes cCollider.h).

	SETTING UP A GAME
	-----------------
	* Add a reference from your game project to the Collision project,
		and make BuildMyGameAssets depend on ColliderBuilder (the same way that it depends on MeshBuilder)
	* Write Content/Collision/game.layers (the game's layers and which of them touch each other)
		and one *.collider file for every kind of collider, and list them in AssetsToBuild.lua
	* In your game:
		* Initialize(): Collision::Initialize( "data/Collision/game.binlayers" ), then load your colliders
		* UpdateSimulationBasedOnTime(): move your objects as usual, then call Collision::Update()
		* CleanUp(): release your colliders, then Collision::CleanUp()
	The user guide (Engine/Collision/UserGuide.md) has the details of both file formats
	and what to add to AssetBuildFunctions.lua.

	The system isn't thread safe: call everything from the thread that runs your simulation
	(UpdateSimulationBasedOnTime() and friends all run on the same thread).
*/

#ifndef EAE6320_COLLISION_H
#define EAE6320_COLLISION_H

// Includes
//=========

#include "cCollider.h"

#include <cstdint>
#include <Engine/Math/sVector.h>
#include <Engine/Results/Results.h>

// Struct Declaration
//===================

namespace eae6320
{
	namespace Collision
	{
		// What Raycast() found
		struct sRaycastHit
		{
			// The closest collider that the ray hit
			// (it is valid until the next Collision::Update();
			// call IncrementReferenceCount() on it if you want to keep it for longer)
			cCollider* collider = nullptr;
			// Where the ray entered the collider's shape (in world space)
			Math::sVector point;
			// The unit normal of the collider's surface at that point
			// (it points out of the collider, back toward the side that the ray came from;
			// e.g. a ray cast straight down onto a floor gets a normal that points up)
			Math::sVector normal;
			// How far the point is from the ray's origin
			float distance = 0.0f;
		};
	}
}

// Interface
//==========

namespace eae6320
{
	namespace Collision
	{
		// Initialize / Clean Up
		//----------------------

		// i_path_layers: the built layers file (e.g. "data/Collision/game.binlayers").
		// Call this before loading any collider.
		cResult Initialize( const char* const i_path_layers );
		// Removes every collider from the world (without sending any events).
		// Release your own references to colliders before calling this.
		cResult CleanUp();

		// Update
		//-------

		// Call this once per simulation update, after your objects have moved. It
		//	1. finds which colliders touch,
		//	2. moves solid colliders out of each other (and removes the part of their velocity that points into each other;
		//		see "RESPONSE" in cCollider.h),
		//	3. sends OnExit, OnEnter and OnStay (in that order) to the colliders involved
		void Update();

		// Raycasts
		//---------

		// Finds the closest collider that a ray hits:
		// the ray starts at i_origin and goes in i_direction (any length but 0; it is normalized) for at most i_maxDistance.
		//	* Only colliders whose layer is in i_layerMask can be hit, e.g. GetLayerMask( "world" )
		//		(the default is every layer; the layers file's interactions don't matter for raycasts)
		//	* Disabled colliders are never hit, and triggers are only hit if i_shouldTriggersBeHit is true
		//	* A ray that starts inside a collider doesn't hit that collider
		//		(so a ray cast from the center of an object never hits the object's own collider)
		// Returns true and fills in o_hit if something was hit (o_hit isn't changed if nothing was hit).
		// It doesn't change anything, so it can be called at any time after Initialize() (even from inside an event);
		// it uses where the colliders' rigid bodies are when it is called.
		//
		// Example: is the player standing on something?
		//	Collision::sRaycastHit hit;
		//	const bool isOnGround = Collision::Raycast( m_player.rigidBodyState.position, Math::sVector( 0.0f, -1.0f, 0.0f ),
		//		playerRadius + 0.05f, hit, Collision::GetLayerMask( "world" ) );
		bool Raycast( const Math::sVector& i_origin, const Math::sVector& i_direction, const float i_maxDistance,
			sRaycastHit& o_hit, const uint32_t i_layerMask = ~uint32_t( 0 ), const bool i_shouldTriggersBeHit = false );

		// Layers
		//-------

		// Returns a mask with only the named layer's bit set (0 if there is no layer with that name).
		// Masks can be combined with |, e.g. GetLayerMask( "world" ) | GetLayerMask( "enemy" ),
		// and compared with cCollider::GetLayerMask()
		uint32_t GetLayerMask( const char* const i_layerName );
		// Finds the index of a layer by its name (returns false if there is no such layer)
		bool GetLayerIndex( const char* const i_layerName, uint8_t& o_layerIndex );
		// Returns the name of a layer (nullptr if the index isn't valid);
		// the string is valid until Collision::CleanUp()
		const char* GetLayerName( const uint8_t i_layerIndex );
		// True if colliders in these two layers can touch each other (according to the layers file)
		bool DoLayersInteract( const uint8_t i_layerA, const uint8_t i_layerB );
	}
}

#endif	// EAE6320_COLLISION_H

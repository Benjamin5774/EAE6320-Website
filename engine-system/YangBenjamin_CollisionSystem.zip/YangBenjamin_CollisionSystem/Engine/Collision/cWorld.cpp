// Includes
//=========

#include "cWorld.h"

#include "cCollider.h"
#include "Collision.h"
#include "Intersections.h"

#include <cmath>
#include <cstring>
#include <Engine/Asserts/Asserts.h>
#include <Engine/Logging/Logging.h>
#include <Engine/Physics/sRigidBodyState.h>
#include <Engine/Platform/Platform.h>
#include <Engine/ScopeGuard/cScopeGuard.h>
#include <limits>
#include <string>
#include <vector>

// Static Data
//============

namespace
{
	// Layers
	//-------

	// The built layers file stays loaded while the system is initialized,
	// so that the arrays and the names in it can be used where they are
	eae6320::Platform::sDataFromFile s_layersFile;
	uint32_t s_layerCount = 0;
	const uint32_t* s_interactionMasks = nullptr;
	const uint32_t* s_nameOffsets = nullptr;
	const char* s_names = nullptr;

	bool s_isInitialized = false;

	// Colliders
	//----------

	// Every collider in the world, in the order in which they were added (which is also the order of their IDs).
	// The world holds one reference to each of them.
	std::vector<eae6320::Collision::cCollider*> s_colliders;
	// (IDs keep counting up even if the system is cleaned up and initialized again)
	uint32_t s_idOfNextCollider = 1;

	// Pairs
	//------

	// Two colliders that touch; "a" is always the one that was added to the world first
	struct sPair
	{
		eae6320::Collision::cCollider* a = nullptr;
		eae6320::Collision::cCollider* b = nullptr;
	};
	// The pairs that touched at the end of the last update,
	// in order of a's ID and then of b's ID
	std::vector<sPair> s_touchingPairs;

	// Events
	//-------

	enum class eEvent : uint8_t
	{
		Enter,
		Stay,
		Exit,
	};

	// What both colliders of a pair are told
	struct sEvent
	{
		sPair pair;
		// From b toward a (the zero vector for an exit)
		eae6320::Math::sVector normal;
		float penetrationDepth = 0.0f;
	};

	// Update() sends events, and an event must not start another Update() or clean up the system
	bool s_isUpdating = false;

	// Response
	//---------

	// A collider can touch several others at once (a ball resting in a corner, a crate on two other crates),
	// and moving it out of one can move it into another (or out of another one as well),
	// so the overlaps are resolved again a few times, each time from where the colliders are after the last pass
	constexpr unsigned int s_maxResolutionPassCount = 4;
}

// Helper Declarations
//====================

namespace
{
	// Gives up the world's references to the colliders that the game has released
	// (after sending OnExit to everything that they were still touching)
	void RemoveReleasedColliders();

	// Moves the solid colliders of the touching pairs out of each other
	// and removes the part of their velocities that points into each other
	void ResolveOverlaps( const std::vector<sEvent>& i_touches );
	// Removes the part of a velocity that points against i_normal
	// (i_normal is a unit vector pointing away from the surface that the velocity mustn't go into)
	void RemoveVelocityIntoSurface( eae6320::Math::sVector& io_velocity, const eae6320::Math::sVector& i_normal );

	// Tells both colliders of every pair, each from its own point of view
	void SendEvents( const eEvent i_event, const std::vector<sEvent>& i_events );
	void SendEvent( const eEvent i_event, eae6320::Collision::cCollider& io_collider, const eae6320::Collision::sContact& i_contact );

	// A number that sorts pairs in the order of their colliders' IDs
	uint64_t GetSortKey( const sPair& i_pair );
	// The shape of a collider where it is right now
	eae6320::Collision::Intersections::sShape GetShape_world( const eae6320::Collision::cCollider& i_collider );
}

// Interface
//==========

// Initialize / Clean Up
//----------------------

eae6320::cResult eae6320::Collision::Internal::cWorld::Initialize( const char* const i_path_layers )
{
	auto result = Results::Success;

	if ( s_isInitialized )
	{
		result = Results::Failure;
		EAE6320_ASSERTF( false, "The collision system has already been initialized" );
		Logging::OutputError( "Collision::Initialize() was called twice without calling Collision::CleanUp() in between" );
		return result;
	}

	// Load the whole built layers file
	Platform::sDataFromFile layersFile;
	{
		std::string errorMessage;
		if ( !( result = Platform::LoadBinaryFile( i_path_layers, layersFile, &errorMessage ) ) )
		{
			EAE6320_ASSERTF( false, "Couldn't load the collision layers file \"%s\": %s", i_path_layers, errorMessage.c_str() );
			Logging::OutputError( "Failed to load the collision layers file \"%s\": %s", i_path_layers, errorMessage.c_str() );
			return result;
		}
	}

	// Extract the four pieces of data
	// (ColliderBuilder wrote them in this order: the number of layers, the interaction masks, the name offsets, the names;
	// every size is checked before anything is used so that a damaged or out-of-date file can't crash the game)
	uint32_t layerCount = 0;
	const uint32_t* interactionMasks = nullptr;
	const uint32_t* nameOffsets = nullptr;
	const char* names = nullptr;
	size_t namesSize = 0;
	const char* problem = nullptr;
	{
		auto currentOffset = reinterpret_cast<uintptr_t>( layersFile.data );
		const auto finalOffset = currentOffset + layersFile.size;
		if ( layersFile.size >= sizeof( layerCount ) )
		{
			layerCount = *reinterpret_cast<const uint32_t*>( currentOffset );
			currentOffset += sizeof( layerCount );
			const auto arraySize = sizeof( uint32_t ) * static_cast<size_t>( layerCount );
			// (there has to be at least one byte of names after the two arrays)
			if ( ( layerCount >= 1 ) && ( layerCount <= MaxLayerCount ) && ( ( finalOffset - currentOffset ) > ( 2 * arraySize ) ) )
			{
				interactionMasks = reinterpret_cast<const uint32_t*>( currentOffset );
				currentOffset += arraySize;
				nameOffsets = reinterpret_cast<const uint32_t*>( currentOffset );
				currentOffset += arraySize;
				names = reinterpret_cast<const char*>( currentOffset );
				namesSize = static_cast<size_t>( finalOffset - currentOffset );
			}
			else
			{
				problem = "the number of layers doesn't match the size of the file";
			}
		}
		else
		{
			problem = "it is too small";
		}
	}
	// Every name must start inside the file and end with a 0 before the file ends,
	// and a layer can only interact with layers that exist
	if ( !problem )
	{
		if ( names[namesSize - 1] != '\0' )
		{
			problem = "the last layer name isn't terminated";
		}
		const auto bitsOfMissingLayers = ( layerCount < 32 ) ? ~( ( uint32_t( 1 ) << layerCount ) - 1 ) : uint32_t( 0 );
		for ( uint32_t i = 0; ( i < layerCount ) && !problem; ++i )
		{
			if ( nameOffsets[i] >= namesSize )
			{
				problem = "a layer name is outside of the file";
			}
			else if ( ( interactionMasks[i] & bitsOfMissingLayers ) != 0 )
			{
				problem = "a layer interacts with a layer that doesn't exist";
			}
		}
	}
	if ( problem )
	{
		result = Results::InvalidFile;
		EAE6320_ASSERTF( false, "The collision layers file \"%s\" is invalid: %s", i_path_layers, problem );
		Logging::OutputError( "The collision layers file \"%s\" is invalid: %s", i_path_layers, problem );
		return result;
	}

	// The file is kept, and the pointers point into it
	s_layersFile = std::move( layersFile );
	s_layerCount = layerCount;
	s_interactionMasks = interactionMasks;
	s_nameOffsets = nameOffsets;
	s_names = names;
	s_isInitialized = true;

	// The log shows which layers the game uses and what touches what, which helps when something doesn't collide
	Logging::OutputMessage( "Collision: initialized with %u layers from \"%s\"", s_layerCount, i_path_layers );
	for ( uint32_t i = 0; i < s_layerCount; ++i )
	{
		std::string touchedLayers;
		for ( uint32_t j = 0; j < s_layerCount; ++j )
		{
			if ( ( s_interactionMasks[i] & ( uint32_t( 1 ) << j ) ) != 0 )
			{
				touchedLayers += touchedLayers.empty() ? "" : ", ";
				touchedLayers += s_names + s_nameOffsets[j];
			}
		}
		Logging::OutputMessage( "Collision:   layer %u \"%s\" touches: %s",
			i, s_names + s_nameOffsets[i], touchedLayers.empty() ? "(nothing)" : touchedLayers.c_str() );
	}

	return result;
}

eae6320::cResult eae6320::Collision::Internal::cWorld::CleanUp()
{
	if ( s_isUpdating )
	{
		EAE6320_ASSERTF( false, "Collision::CleanUp() can't be called from inside a collision event" );
		Logging::OutputError( "Collision::CleanUp() was called from inside a collision event, which isn't allowed" );
		return Results::Failure;
	}

	// The world gives up all of its references without sending any events (the game is shutting the system down).
	// A collider that the game still holds stays alive until the game releases it, but it isn't in the world any more.
	{
		unsigned int colliderCount_stillHeld = 0;
		for ( auto* const collider : s_colliders )
		{
			if ( IsHeldByGame( *collider ) )
			{
				++colliderCount_stillHeld;
			}
			collider->DecrementReferenceCount();
		}
		if ( colliderCount_stillHeld > 0 )
		{
			Logging::OutputMessage( "Collision: %u collider(s) were still held by the game when the collision system was cleaned up"
				" (release your colliders before calling Collision::CleanUp())", colliderCount_stillHeld );
		}
		s_colliders.clear();
		s_touchingPairs.clear();
	}
	// Layers
	{
		s_layersFile.Free();
		s_layerCount = 0;
		s_interactionMasks = nullptr;
		s_nameOffsets = nullptr;
		s_names = nullptr;
	}
	s_isInitialized = false;

	return Results::Success;
}

bool eae6320::Collision::Internal::cWorld::IsInitialized()
{
	return s_isInitialized;
}

// Update
//-------

void eae6320::Collision::Internal::cWorld::Update()
{
	if ( !s_isInitialized )
	{
		EAE6320_ASSERTF( false, "Collision::Update() was called before Collision::Initialize()" );
		return;
	}
	if ( s_isUpdating )
	{
		EAE6320_ASSERTF( false, "Collision::Update() can't be called from inside a collision event" );
		return;
	}
	s_isUpdating = true;
	cScopeGuard scopeGuard_isUpdating( []
		{
			s_isUpdating = false;
		} );

	// Colliders that the game released since the last update leave the world first,
	// before anything looks at their rigid bodies (which might not exist any more)
	RemoveReleasedColliders();

	// Find every pair of colliders that touch now
	std::vector<sEvent> touches;
	{
		// Each collider's shape is calculated once rather than once per pair
		const auto colliderCount = s_colliders.size();
		std::vector<Intersections::sShape> shapes( colliderCount );
		for ( size_t i = 0; i < colliderCount; ++i )
		{
			shapes[i] = GetShape_world( *s_colliders[i] );
		}
		// Every pair that could touch is tested once
		// (skipping pairs that are far apart without testing them, a "broad phase", is one of my stretch goals)
		for ( size_t i = 0; i < colliderCount; ++i )
		{
			const auto& collider_a = *s_colliders[i];
			if ( !collider_a.IsEnabled() )
			{
				continue;
			}
			for ( size_t j = i + 1; j < colliderCount; ++j )
			{
				const auto& collider_b = *s_colliders[j];
				if ( !collider_b.IsEnabled()
					// Static colliders never move, so two of them don't need to be tested
					|| ( collider_a.IsStatic() && collider_b.IsStatic() )
					// The layers file decides which colliders can touch at all
					|| !DoLayersInteract( collider_a.GetLayer(), collider_b.GetLayer() ) )
				{
					continue;
				}
				sEvent touch;
				touch.pair = sPair{ s_colliders[i], s_colliders[j] };
				if ( Intersections::DoShapesTouch( shapes[i], shapes[j], touch.normal, touch.penetrationDepth ) )
				{
					touches.push_back( touch );
				}
			}
		}
		// (the colliders are in the order of their IDs, so the touches are already sorted the same way as s_touchingPairs)
	}

	// Keep solid colliders out of each other.
	// This happens before any event is sent, so that event functions see where the objects really are now
	// (the contacts that they are given still describe the overlap that was found, before it was resolved)
	ResolveOverlaps( touches );

	// Compare them with the pairs that touched after the last update
	std::vector<sEvent> enters, stays, exits;
	{
		// Both lists are sorted, so walking through them side by side finds
		// the pairs that are only in the old list (exits), only in the new one (enters), or in both (stays)
		constexpr auto noMorePairs = std::numeric_limits<uint64_t>::max();
		size_t index_old = 0, index_new = 0;
		while ( ( index_old < s_touchingPairs.size() ) || ( index_new < touches.size() ) )
		{
			const auto key_old = ( index_old < s_touchingPairs.size() ) ? GetSortKey( s_touchingPairs[index_old] ) : noMorePairs;
			const auto key_new = ( index_new < touches.size() ) ? GetSortKey( touches[index_new].pair ) : noMorePairs;
			if ( key_old < key_new )
			{
				sEvent exit;
				exit.pair = s_touchingPairs[index_old];
				exits.push_back( exit );
				++index_old;
			}
			else if ( key_new < key_old )
			{
				enters.push_back( touches[index_new] );
				++index_new;
			}
			else
			{
				stays.push_back( touches[index_new] );
				++index_old;
				++index_new;
			}
		}
		// The pairs that touch now are what the next update compares against
		s_touchingPairs.clear();
		for ( const auto& touch : touches )
		{
			s_touchingPairs.push_back( touch.pair );
		}
	}

	// Tell the colliders
	SendEvents( eEvent::Exit, exits );
	SendEvents( eEvent::Enter, enters );
	SendEvents( eEvent::Stay, stays );

	// Colliders that the game released from inside the events leave the world now,
	// so that whatever they were touching gets its OnExit in this update rather than in the next one
	RemoveReleasedColliders();
}

// Raycasts
//---------

bool eae6320::Collision::Internal::cWorld::Raycast( const Math::sVector& i_origin, const Math::sVector& i_direction, const float i_maxDistance,
	sRaycastHit& o_hit, const uint32_t i_layerMask, const bool i_shouldTriggersBeHit )
{
	if ( !s_isInitialized )
	{
		EAE6320_ASSERTF( false, "Collision::Raycast() was called before Collision::Initialize()" );
		return false;
	}
	const auto directionLength = i_direction.GetLength();
	// (the comparisons are written so that NaN fails them)
	if ( !( directionLength > 0.0f ) || !std::isfinite( directionLength ) )
	{
		EAE6320_ASSERTF( false, "A ray's direction can't be the zero vector" );
		Logging::OutputError( "Collision::Raycast() was called with a direction of zero length (nothing can be hit)" );
		return false;
	}
	if ( !( i_maxDistance >= 0.0f ) )
	{
		EAE6320_ASSERTF( false, "A ray's maximum distance can't be negative" );
		return false;
	}
	const auto direction = i_direction * ( 1.0f / directionLength );

	// Every collider that the ray could hit is tested,
	// and each test only looks as far as the closest hit found so far
	// (a "broad phase" that skips colliders that are nowhere near the ray is one of my stretch goals)
	sRaycastHit closestHit;
	bool wasAnythingHit = false;
	float maxDistance = i_maxDistance;
	for ( auto* const collider : s_colliders )
	{
		if ( !collider->IsEnabled()
			// A collider that the game has released is only still here until the next Update() can remove it safely
			|| !IsHeldByGame( *collider )
			|| ( ( collider->GetLayerMask() & i_layerMask ) == 0 )
			|| ( collider->IsTrigger() && !i_shouldTriggersBeHit ) )
		{
			continue;
		}
		float distance;
		Math::sVector normal;
		if ( Intersections::DoesRayHitShape( i_origin, direction, maxDistance, GetShape_world( *collider ), distance, normal ) )
		{
			wasAnythingHit = true;
			maxDistance = distance;
			closestHit.collider = collider;
			closestHit.normal = normal;
			closestHit.distance = distance;
		}
	}
	if ( wasAnythingHit )
	{
		closestHit.point = i_origin + ( direction * closestHit.distance );
		o_hit = closestHit;
	}
	return wasAnythingHit;
}

// Colliders
//----------

void eae6320::Collision::Internal::cWorld::Add( cCollider& io_collider )
{
	EAE6320_ASSERT( s_isInitialized );
	io_collider.m_id = s_idOfNextCollider++;
	// The world keeps its own reference until the game has released the collider
	io_collider.IncrementReferenceCount();
	s_colliders.push_back( &io_collider );
}

bool eae6320::Collision::Internal::cWorld::IsHeldByGame( const cCollider& i_collider )
{
	// One of the references is the world's
	return i_collider.m_referenceCount > 1;
}

// Layers
//-------

unsigned int eae6320::Collision::Internal::cWorld::GetLayerCount()
{
	return s_layerCount;
}

bool eae6320::Collision::Internal::cWorld::GetLayerIndex( const char* const i_layerName, uint8_t& o_layerIndex )
{
	if ( i_layerName )
	{
		for ( uint32_t i = 0; i < s_layerCount; ++i )
		{
			if ( std::strcmp( s_names + s_nameOffsets[i], i_layerName ) == 0 )
			{
				o_layerIndex = static_cast<uint8_t>( i );
				return true;
			}
		}
	}
	return false;
}

const char* eae6320::Collision::Internal::cWorld::GetLayerName( const uint8_t i_layerIndex )
{
	return ( i_layerIndex < s_layerCount ) ? ( s_names + s_nameOffsets[i_layerIndex] ) : nullptr;
}

bool eae6320::Collision::Internal::cWorld::DoLayersInteract( const uint8_t i_layerA, const uint8_t i_layerB )
{
	return ( i_layerA < s_layerCount ) && ( i_layerB < s_layerCount )
		&& ( ( s_interactionMasks[i_layerA] & ( uint32_t( 1 ) << i_layerB ) ) != 0 );
}

// Helper Definitions
//===================

namespace
{
	void RemoveReleasedColliders()
	{
		// An OnExit sent from here can make the game release more colliders,
		// so this repeats until there is nothing more to remove
		while ( true )
		{
			std::vector<eae6320::Collision::cCollider*> releasedColliders;
			{
				size_t keptColliderCount = 0;
				for ( auto* const collider : s_colliders )
				{
					if ( eae6320::Collision::Internal::cWorld::IsHeldByGame( *collider ) )
					{
						s_colliders[keptColliderCount++] = collider;
					}
					else
					{
						releasedColliders.push_back( collider );
					}
				}
				s_colliders.resize( keptColliderCount );
			}
			if ( releasedColliders.empty() )
			{
				return;
			}
			// Everything that a released collider was touching stops touching it
			std::vector<sEvent> exits;
			{
				size_t keptPairCount = 0;
				for ( const auto& pair : s_touchingPairs )
				{
					if ( eae6320::Collision::Internal::cWorld::IsHeldByGame( *pair.a )
						&& eae6320::Collision::Internal::cWorld::IsHeldByGame( *pair.b ) )
					{
						s_touchingPairs[keptPairCount++] = pair;
					}
					else
					{
						sEvent exit;
						exit.pair = pair;
						exits.push_back( exit );
					}
				}
				s_touchingPairs.resize( keptPairCount );
			}
			// (the released collider itself is skipped, only the one it was touching is told)
			SendEvents( eEvent::Exit, exits );
			// The world's reference is normally the last one, and this deletes the collider
			for ( auto* const collider : releasedColliders )
			{
				collider->DecrementReferenceCount();
			}
		}
	}

	void ResolveOverlaps( const std::vector<sEvent>& i_touches )
	{
		// Only pairs where neither collider is a trigger push each other
		// (a pair of two static colliders is never in the list, because they are never tested)
		std::vector<sPair> solidPairs;
		for ( const auto& touch : i_touches )
		{
			if ( !touch.pair.a->IsTrigger() && !touch.pair.b->IsTrigger() )
			{
				solidPairs.push_back( touch.pair );
			}
		}

		for ( unsigned int passIndex = 0; ( passIndex < s_maxResolutionPassCount ) && !solidPairs.empty(); ++passIndex )
		{
			bool wasAnythingMoved = false;
			for ( const auto& pair : solidPairs )
			{
				// The overlap is found again from where the colliders are now
				// (an earlier pair might already have moved one of them)
				eae6320::Math::sVector normal;
				float penetrationDepth;
				if ( !eae6320::Collision::Intersections::DoShapesTouch( GetShape_world( *pair.a ), GetShape_world( *pair.b ),
					normal, penetrationDepth ) )
				{
					continue;
				}
				// The normal points from b toward a
				auto& rigidBody_a = pair.a->GetRigidBody();
				auto& rigidBody_b = pair.b->GetRigidBody();
				if ( pair.b->IsStatic() )
				{
					// Only a moves: all of the way out, and it can't keep moving into b
					rigidBody_a.position += normal * penetrationDepth;
					RemoveVelocityIntoSurface( rigidBody_a.velocity, normal );
				}
				else if ( pair.a->IsStatic() )
				{
					// Only b moves (b's normal is the opposite of a's)
					rigidBody_b.position -= normal * penetrationDepth;
					RemoveVelocityIntoSurface( rigidBody_b.velocity, -normal );
				}
				else
				{
					// Both are dynamic: each moves half of the way
					const auto halfOfTheCorrection = normal * ( penetrationDepth * 0.5f );
					rigidBody_a.position += halfOfTheCorrection;
					rigidBody_b.position -= halfOfTheCorrection;
					// and the speed at which they were approaching each other is taken away from both equally
					// (as if they had the same mass and didn't bounce)
					const auto approachingSpeed = eae6320::Math::Dot( rigidBody_a.velocity - rigidBody_b.velocity, normal );
					if ( approachingSpeed < 0.0f )
					{
						const auto halfOfTheVelocityChange = normal * ( approachingSpeed * 0.5f );
						rigidBody_a.velocity -= halfOfTheVelocityChange;
						rigidBody_b.velocity += halfOfTheVelocityChange;
					}
				}
				// (two colliders that are just touching aren't moved, but their velocities still can't point into each other)
				if ( penetrationDepth > 0.0f )
				{
					wasAnythingMoved = true;
				}
			}
			// Once a pass doesn't move anything every overlap has been resolved
			if ( !wasAnythingMoved )
			{
				break;
			}
		}
	}

	void RemoveVelocityIntoSurface( eae6320::Math::sVector& io_velocity, const eae6320::Math::sVector& i_normal )
	{
		// A negative speed along the normal is movement into the surface;
		// moving away from it or along it is left alone (so objects slide along walls and can jump off floors)
		const auto speedAlongNormal = eae6320::Math::Dot( io_velocity, i_normal );
		if ( speedAlongNormal < 0.0f )
		{
			io_velocity -= i_normal * speedAlongNormal;
		}
	}

	void SendEvents( const eEvent i_event, const std::vector<sEvent>& i_events )
	{
		for ( const auto& event : i_events )
		{
			// Each collider gets a contact from its own point of view:
			// the other collider, and a normal that points toward itself
			eae6320::Collision::sContact contact_a;
			contact_a.other = event.pair.b;
			contact_a.normal = event.normal;
			contact_a.penetrationDepth = event.penetrationDepth;
			SendEvent( i_event, *event.pair.a, contact_a );

			eae6320::Collision::sContact contact_b;
			contact_b.other = event.pair.a;
			// (subtracted from zero rather than negated so that zero components stay 0 instead of becoming -0)
			contact_b.normal = eae6320::Math::sVector() - event.normal;
			contact_b.penetrationDepth = event.penetrationDepth;
			SendEvent( i_event, *event.pair.b, contact_b );
		}
	}

	void SendEvent( const eEvent i_event, eae6320::Collision::cCollider& io_collider, const eae6320::Collision::sContact& i_contact )
	{
		// A collider that the game has released gets no more events
		// (the world only keeps it alive until it can be removed safely, and what its functions refer to may be gone)
		if ( !eae6320::Collision::Internal::cWorld::IsHeldByGame( io_collider ) )
		{
			return;
		}
		// The function is copied before it is called
		// so that it is safe for it to replace itself (e.g. collider->OnEnter = nullptr) while it runs
		const auto function = ( i_event == eEvent::Enter ) ? io_collider.OnEnter
			: ( ( i_event == eEvent::Stay ) ? io_collider.OnStay : io_collider.OnExit );
		if ( function )
		{
			function( i_contact );
		}
	}

	uint64_t GetSortKey( const sPair& i_pair )
	{
		return ( static_cast<uint64_t>( i_pair.a->GetId() ) << 32 ) | static_cast<uint64_t>( i_pair.b->GetId() );
	}

	eae6320::Collision::Intersections::sShape GetShape_world( const eae6320::Collision::cCollider& i_collider )
	{
		eae6320::Collision::Intersections::sShape shape;
		shape.center = i_collider.GetCenter();
		shape.halfSize = i_collider.GetHalfSize();
		shape.radius = i_collider.GetRadius();
		shape.shape = i_collider.GetShape();
		return shape;
	}
}
